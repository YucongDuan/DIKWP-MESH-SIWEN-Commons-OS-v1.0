# Changelog

## v1.0.0 - 2026-07-19

- Initial policy-to-protocol reference runtime.
- Full 25-transform DIKWP-MESH² registry.
- Four-question and four-response policy compiler.
- Seven-part agent-interconnection standards bridge.
- Five-level human-control gate.
- Fourteen deterministic shadow scenarios.
- Offline dashboard, schemas, tests, Word specification and validation package.
