from __future__ import annotations

import json
from pathlib import Path
from typing import Iterable

from docx import Document
from docx.enum.table import WD_CELL_VERTICAL_ALIGNMENT, WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.style import WD_STYLE_TYPE
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Cm, Pt, RGBColor

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'docs'/'段玉聪_DIKWP-MESH²_SIWEN_COMMONS_中国AI四问可信智能体公共基座_v1.0_CN_最终版.docx'
release=json.loads((ROOT/'outputs/demo/release.json').read_text(encoding='utf-8'))
policy=release['policy_compilation']; bridge=release['standard_bridge']; results=release['scenario_results']; bundle=release['public_product_bundle']; summary=release['summary']; ledger=release['ledger']

TITLE='DIKWP-MESH² SIWEN Commons OS v1.0'
SUBTITLE='段玉聪中国智能时代四问、可信智能体人类控制、标准互操作与普惠公共基座'
FONT_EAST='Noto Sans CJK SC'; FONT_LATIN='Liberation Sans'


def set_run_font(run,east=FONT_EAST,latin=FONT_LATIN):
    run.font.name=latin
    rpr=run._element.get_or_add_rPr(); fonts=rpr.rFonts
    if fonts is None:
        fonts=OxmlElement('w:rFonts');rpr.insert(0,fonts)
    fonts.set(qn('w:ascii'),latin);fonts.set(qn('w:hAnsi'),latin);fonts.set(qn('w:eastAsia'),east)


def shade(cell,fill):
    tcPr=cell._tc.get_or_add_tcPr();shd=OxmlElement('w:shd');shd.set(qn('w:fill'),fill);tcPr.append(shd)


def margins(cell,top=80,start=90,bottom=80,end=90):
    tcPr=cell._tc.get_or_add_tcPr();tcMar=tcPr.first_child_found_in('w:tcMar')
    if tcMar is None:tcMar=OxmlElement('w:tcMar');tcPr.append(tcMar)
    for name,val in [('top',top),('start',start),('bottom',bottom),('end',end)]:
        node=tcMar.find(qn(f'w:{name}'))
        if node is None:node=OxmlElement(f'w:{name}');tcMar.append(node)
        node.set(qn('w:w'),str(val));node.set(qn('w:type'),'dxa')


def repeat_header(row):
    trPr=row._tr.get_or_add_trPr();el=OxmlElement('w:tblHeader');el.set(qn('w:val'),'true');trPr.append(el)


def cant_split(row):
    trPr=row._tr.get_or_add_trPr()
    if trPr.find(qn('w:cantSplit')) is None:
        trPr.append(OxmlElement('w:cantSplit'))


def set_col_widths(table,widths):
    for row in table.rows:
        for i,w in enumerate(widths):
            if i<len(row.cells):row.cells[i].width=Cm(w)


def page_number(p):
    p.alignment=WD_ALIGN_PARAGRAPH.CENTER
    r=p.add_run('第 ');set_run_font(r)
    begin=OxmlElement('w:fldChar');begin.set(qn('w:fldCharType'),'begin')
    instr=OxmlElement('w:instrText');instr.set(qn('xml:space'),'preserve');instr.text='PAGE'
    end=OxmlElement('w:fldChar');end.set(qn('w:fldCharType'),'end')
    r._r.extend([begin,instr,end])
    r2=p.add_run(' 页');set_run_font(r2)


def heading(doc,text,level=1):
    p=doc.add_paragraph(text,style=f'Heading {level}')
    p.paragraph_format.keep_with_next=True
    for r in p.runs:set_run_font(r)
    return p


def para(doc,text,indent=True,bold_prefix=None):
    p=doc.add_paragraph();p.paragraph_format.space_after=Pt(5);p.paragraph_format.line_spacing=1.18
    if indent:p.paragraph_format.first_line_indent=Cm(.74)
    if bold_prefix and text.startswith(bold_prefix):
        r=p.add_run(bold_prefix);r.bold=True;set_run_font(r)
        r2=p.add_run(text[len(bold_prefix):]);set_run_font(r2)
    else:
        r=p.add_run(text);set_run_font(r)
    return p


def bullet(doc,text,level=0):
    p=doc.add_paragraph(style='List Bullet' if level==0 else 'List Bullet 2');p.paragraph_format.space_after=Pt(2);p.paragraph_format.line_spacing=1.08
    r=p.add_run(text);set_run_font(r);return p


def callout(doc,title,text,fill='EAF3F7'):
    t=doc.add_table(rows=1,cols=1);t.alignment=WD_TABLE_ALIGNMENT.CENTER
    repeat_header(t.rows[0]);cant_split(t.rows[0])
    c=t.cell(0,0);shade(c,fill);margins(c,140,180,140,180)
    p=c.paragraphs[0];r=p.add_run(title);r.bold=True;r.font.size=Pt(11.5);set_run_font(r)
    p2=c.add_paragraph();p2.paragraph_format.space_after=Pt(0);p2.paragraph_format.line_spacing=1.14
    r2=p2.add_run(text);set_run_font(r2)
    doc.add_paragraph().paragraph_format.space_after=Pt(0)


def table(doc,headers,rows,widths=None,font_size=8.5):
    rows=list(rows);t=doc.add_table(rows=1,cols=len(headers));t.style='Table Grid';t.alignment=WD_TABLE_ALIGNMENT.CENTER
    repeat_header(t.rows[0]);cant_split(t.rows[0])
    for i,h in enumerate(headers):
        c=t.rows[0].cells[i];shade(c,'DCECF2');margins(c);c.vertical_alignment=WD_CELL_VERTICAL_ALIGNMENT.CENTER
        p=c.paragraphs[0];p.alignment=WD_ALIGN_PARAGRAPH.CENTER
        r=p.add_run(str(h));r.bold=True;r.font.size=Pt(font_size);set_run_font(r)
    for row in rows:
        new_row=t.add_row();cant_split(new_row);cells=new_row.cells
        for i,val in enumerate(row):
            c=cells[i];margins(c);c.vertical_alignment=WD_CELL_VERTICAL_ALIGNMENT.CENTER
            p=c.paragraphs[0];p.paragraph_format.space_after=Pt(0);p.paragraph_format.line_spacing=1.02
            r=p.add_run(str(val));r.font.size=Pt(font_size);set_run_font(r)
    if widths:set_col_widths(t,widths)
    doc.add_paragraph().paragraph_format.space_after=Pt(0)
    return t


def image(doc,path,caption,width=16.2):
    p=doc.add_paragraph();p.alignment=WD_ALIGN_PARAGRAPH.CENTER
    shape=p.add_run().add_picture(str(path),width=Cm(width))
    shape._inline.docPr.set('descr',caption);shape._inline.docPr.set('title',caption)
    cp=doc.add_paragraph();cp.alignment=WD_ALIGN_PARAGRAPH.CENTER;cp.paragraph_format.space_after=Pt(7)
    r=cp.add_run(caption);r.italic=True;r.font.size=Pt(9);set_run_font(r)


def styles(doc):
    normal=doc.styles['Normal'];normal.font.name=FONT_LATIN;normal._element.rPr.rFonts.set(qn('w:eastAsia'),FONT_EAST);normal.font.size=Pt(10.5);normal.paragraph_format.line_spacing=1.18;normal.paragraph_format.space_after=Pt(5)
    for name,size,color,bold in [('Title',26,'17384F',True),('Subtitle',14,'3D6175',False)]:
        st=doc.styles[name] if name in doc.styles else doc.styles.add_style(name,WD_STYLE_TYPE.PARAGRAPH)
        st.font.name=FONT_LATIN;st._element.rPr.rFonts.set(qn('w:eastAsia'),FONT_EAST);st.font.size=Pt(size);st.font.color.rgb=RGBColor.from_string(color);st.font.bold=bold;st.paragraph_format.alignment=WD_ALIGN_PARAGRAPH.CENTER
    for i,size in [(1,17),(2,14),(3,12)]:
        st=doc.styles[f'Heading {i}'];st.font.name=FONT_LATIN;st._element.rPr.rFonts.set(qn('w:eastAsia'),FONT_EAST);st.font.size=Pt(size);st.font.bold=True;st.font.color.rgb=RGBColor(20,76,102) if i<3 else RGBColor(50,83,100);st.paragraph_format.space_before=Pt(9 if i==1 else 6);st.paragraph_format.space_after=Pt(5);st.paragraph_format.keep_with_next=True


def title_page(doc):
    p=doc.add_paragraph(style='Title');p.add_run(TITLE)
    for r in p.runs:set_run_font(r)
    p2=doc.add_paragraph(style='Subtitle');p2.add_run(SUBTITLE)
    for r in p2.runs:set_run_font(r)
    doc.add_paragraph();doc.add_paragraph()
    callout(doc,'系统方法边界','本系统不为“人工智能、智能体、意识、安全、文化、普惠、治理”等概念给出观察者无关的终局定义。它把政策、标准、场景与受影响者意见编译为带观察者、情境、目的、证据、转换路径、冲突和残余的语义对象，再通过全部 25 类共等 DIKWP×DIKWP 变换形成可运行的控制证据。','E6F2F5')
    table(doc,['交付字段','内容'],[
        ('版本','v1.0.0 独立参考实现'),('交付日期','2026 年 7 月 19 日'),('政策输入','2026 WAIC 主旨讲话、主席声明、“人工智能+”行动意见、智能体实施意见'),('标准输入','人工智能智能体互联七部分标准家族'),('核心输出','政策语义编译、目的场、决策边界、工具租约、人类控制、十四场景、符合性回执、事件账本'),('不构成','政策权威解释、法律意见、国家标准认证、生产部署许可、人工意识证明或机构背书')
    ],widths=[4.1,12.1],font_size=9.3)
    para(doc,'本系统名称 SIWEN 只是“智能时代四问”的项目协作句柄，不是新的概念本体，也不位于 DIKWP-MESH² 之上。',indent=False)
    doc.add_page_break()


def navigation(doc):
    heading(doc,'内容导航',1)
    items=[
        '执行摘要：把四个时代问题编译为可运行公共控制对象','一、最新政策信号与中国未来 AI 的结构性需求','二、段玉聪 GitHub 资产与缺失的关键层','三、无定义 DIKWP-MESH² 方法与 25 类变换','四、系统总体架构与数据流','五、四问：相处、安全、治理、普惠','六、四策：开放、安全、文明、全球治理','七、智能体互联七部分标准桥','八、身份、能力、目的、边界与工具租约','九、人类最终控制、知情、申诉和恢复','十、文明语境、普惠、劳动与绿色算力','十一、十四个 AI+ 影子场景','十二、证据、事件、回执与追加式账本','十三、与 ROOTS、PACT、MANDATE、AccordMesh、NEXUS 的组合','十四、GitHub source-first 与共同维护','十五、90 天执行路线与 12 个月发展目标','十六、KPI、风险、Kill 条件和真实边界','附录 A—E：变换矩阵、对象表、命令、检查表与来源'
    ]
    for x in items:bullet(doc,x)
    doc.add_page_break()

def main_content(doc):
    heading(doc,'执行摘要：把四个时代问题编译为可运行公共控制对象',1)
    para(doc,'中国未来人工智能的发展任务正在从“模型能不能回答”转向“智能体能不能在真实社会和物理世界中可靠行动”。2026 年世界人工智能大会主旨讲话提出四个时代问题：机器开始思考后人类如何相处，算法参与决策时安全如何保障，技术挑战伦理时治理如何跟上，数智鸿沟扩大时普惠如何实现。主旨讲话同时提出开放共赢、安全可控、文明互鉴、全球治理四项方向。主席声明又把智能体决策权限、行为边界、行为追溯、风险提示、开源生态、数据可追溯、绿色算力、就业转型和全球南方能力建设放入同一议程。')
    para(doc,'这些要求不是一个新的“AI 总定义”，而是一组彼此牵制的现实关系。开放可能扩大创新，也可能扩大滥用面；人类控制可能提高安全，也可能被简化为形式确认；文明互鉴要求保留差异，却与统一接口和规模化产品形成张力；普惠要求低成本和广覆盖，却可能增加能耗、维护负担和数字依赖。真正关键的系统不能只为其中一项优化，而要保存这些张力，使不同主体能够在具体场景中协商、否决、复核和修订。')
    callout(doc,'关键系统选择','段玉聪现有 GitHub 已经拥有无定义语义探究、目的保障、多主体授权、智能体联邦、仓库迁移和开放复现等模块。当前缺失的是一个把中国最新政策和七部分智能体互联标准转换为公共控制对象、影子场景、证据回执和事件学习闭环的独立执行层。SIWEN Commons OS 补的是“政策—标准—场景—证据”这一层，而不是再提出一个意识或治理本体。')
    para(doc,f'参考实现共编译 {summary["policy_count"]} 份政策文件、{summary["clause_count"]} 条结构化条款，覆盖全部 25 类 DIKWP×DIKWP 变换，映射七部分智能体互联标准，运行 {summary["scenario_count"]} 个确定性影子场景，并生成 {summary["public_product_count"]} 类公共产品。十四个场景的参考门控全部与预设结果一致：ALLOW 4 个、REVIEW 1 个、HOLD 5 个、BLOCK 2 个、KILL 2 个。追加式账本验证通过。')
    image(doc,ROOT/'assets'/'architecture_cn.png','图 1  DIKWP-MESH² SIWEN Commons OS 总体架构')

    heading(doc,'一、最新政策信号与中国未来 AI 的结构性需求',1)
    heading(doc,'1.1 从“数字世界”到“物理世界”',2)
    para(doc,'智能体正在把模型的错误从文本层带入现实资源层。一个回答错误可以被用户忽略，一个能够调用数据库、支付、机器人、工业设备或公共服务流程的智能体却可能把错误固化为外部后果。因此，未来 AI 基础设施必须把“建议”和“执行”分开，把模型能力与行动资格分开，把可交互性与可授权性分开。SIWEN 将任何外部动作都表示为带有身份、目的、工具租约、资源限制、审批、有效期和回滚条件的 Action Ticket，而不是把自然语言命令直接传给工具。')
    para(doc,'中国“人工智能+”目标要求智能终端和智能体在较短时间内广泛进入科学技术、产业发展、消费、民生和公共治理。这意味着治理不能只依赖少量人工专家逐条审查，而需要机器可读的标准对象、可复用组件和自动化证据。然而自动化治理本身也可能僵化，因此每个自动规则都必须带观察者、适用场景、反例、申诉和版本。')
    heading(doc,'1.2 六个不能被单一指标压缩的矛盾',2)
    table(doc,['结构矛盾','一侧需求','另一侧需求','SIWEN 处理'],[
        ('创新—安全','快速开源、快速试验','限制危险能力和外部副作用','分级开放、影子环境、ToolLease 与 Kill 条件'),
        ('自主—控制','提高智能体自主完成度','保留人类最终决定和责任','DecisionBoundary 与 HumanControlPlan'),
        ('统一—多样','统一接口、规模化复用','保留文化、法律和场景差异','标准桥 + CultureContext + 残余账本'),
        ('普及—普惠','高采用率和广覆盖','避免弱势群体被排除或操纵','InclusionPlan、人工帮助、低资源模式'),
        ('能力—证据','快速展示能力','确保独立复现和失败可见','ConformanceReceipt 与 Failure Report'),
        ('算力—可持续','更强模型、更长推理','能源、电力、成本和生态约束','EnergyBudget 与必要性审计')
    ],widths=[2.5,4.2,4.2,5.3],font_size=8.2)
    para(doc,'这六个矛盾不是需要一次性消除的“问题”，而是未来智能社会的长期边界条件。系统若只输出一个综合分数，就会把安全、尊严、文化和能源的不可通约差异隐藏起来。SIWEN 因而采用多对象、多门禁和残余保存，而不是简单把所有要求加权求和。')

    heading(doc,'二、段玉聪 GitHub 资产与缺失的关键层',1)
    heading(doc,'2.1 公开资产的结构信号',2)
    para(doc,'2026 年 7 月 19 日的公开页面快照显示，段玉聪 GitHub 已经形成二百余个公开仓库，研究主题集中于 DIKWP、人工意识、语义计算、可信智能体、数字生命、未来预测与开源治理。最新仓库中，ROOTS 强调无定义语义探究和完整二十五类变换；PACT 处理目的与权限保障；MANDATE 处理多主体授权、终止和演化；AccordMesh 处理智能体间语义交换和联盟；NEXUS 处理 source-first 迁移和模块组合。')
    para(doc,'这些资产说明核心理论与原型并不缺失。真正缺少的是一个能够直接回应中国智能体政策、国家互联标准和实际场景责任要求的公共控制层。若继续新增同义概念仓库，外部参与者仍然难以判断哪个项目对应哪项政策要求、如何与标准对接、如何在场景中验收。SIWEN 因此被设计为“组合任务”：它调用现有模块，而不取代现有模块。')
    heading(doc,'2.2 五个已有模块与一个缺口',2)
    table(doc,['现有模块','已有能力','本系统调用方式','仍需补充'],[
        ('MESH² ROOTS','无定义语义束、观察者索引、25 类变换','作为政策语义编译内核','政策条款和公共控制对象'),
        ('PACT','Purpose/Permission 保障与配对场景','作为门控与基准上游','中国标准对象、普惠与文化扩展'),
        ('MANDATE','多主体授权、终止、责任','作为授权与多签上游','人类最终决定和公共申诉'),
        ('AccordMesh','智能体联邦与语义交换','作为互联和跨域协同上游','七部分标准映射和数据权限'),
        ('NEXUS FORGE','source-first 迁移、模块注册、任务组合','作为 GitHub 执行层','政策快照、场景和 Release 证据'),
        ('缺失层','政策—标准—场景—证据闭环','由 SIWEN 补齐','四问、四策、七标准、十四场景和事件学习')
    ],widths=[3.0,4.2,4.2,4.8],font_size=8.3)
    para(doc,'SIWEN 不应成为第一个要求其他仓库遵守规则、自己却仍以整包 ZIP 作为唯一公共入口的治理仓库。正式发布时必须将源码、Schema、测试、数据和场景直接放在根目录，并由非创始维护者完成一次 Release 演练。')

    heading(doc,'三、无定义 DIKWP-MESH² 方法与 25 类变换',1)
    heading(doc,'3.1 不先定义“智能体”和“人类控制”',2)
    para(doc,'同一个“智能体”可以指云端助手、手机管家、工业控制代理、科研自动化系统、公共服务前台或多机器人协同节点。不同场景的感知、记忆、决策、执行和责任边界完全不同。如果先给出一个统一实体定义，系统容易把低风险办公助手和关键基础设施控制代理放入同一尺度。SIWEN 只登记当前任务中可观察的能力、权限、作用对象和后果，不把名称本身当作资格。')
    para(doc,'“人类控制”同样不能被定义成一个布尔字段。真实控制至少包含信息权、拒绝权、暂停权、回滚权、审查权、申诉权和责任承担能力。某个用户可以点击确认，却不理解行动后果；某个机构名义上负责，却没有技术停止权限；某个操作员可以停机，却承担不了法律责任。系统必须把这些关系分别记录。')
    heading(doc,'3.2 二十五类共等变换',2)
    para(doc,'D、I、K、W、P 在本系统中不是从低到高的五层，而是五种可以互相转换、互相质疑的语义资源角色。政策目的可以影响数据采集，但新数据也必须能够终止政策假设；知识可以支持行动，却不能自动授权行动；价值判断可以限制目的，也必须请求可能推翻自身的数据。')
    image(doc,ROOT/'assets'/'four_questions_cn.png','图 2  智能时代四问到可执行控制对象')
    matrix_rows=[]
    for x in policy['transformations']:
        matrix_rows.append((x['transform_code'],x['operation'],x['question'],x['common_loss'],x['recovery']))
    table(doc,['变换','操作','核心问题','常见损失','恢复机制'],matrix_rows,widths=[1.4,2.8,4.6,3.5,3.8],font_size=7.2)
    heading(doc,'3.3 Purpose 不是最高层',2)
    para(doc,'PurposeField 保存多个目的持有者：用户、开发者、部署者、监管者、受影响者、劳动者、文化社群、全球南方合作方和公共基础设施责任主体。目的可以相互支持，也可以相互否决。例如，“扩大公共服务效率”不能自动覆盖“保障申请人最终申诉”；“推动开源开放”不能自动覆盖“防止危险工具无责任扩散”；“降低成本”不能自动覆盖“残障用户可达性”。')
    para(doc,'系统通过 P→P 变换记录目的协商、委托、暂停和撤销，通过 D→P、I→P、K→P、W→P 允许事实、关系、知识和价值反向修改目的。参考运行中的 PurposeField 包含多个持有者和多种可否决关系，未出现单一不可修改目的。')

    heading(doc,'四、系统总体架构与数据流',1)
    heading(doc,'4.1 十个连续环节',2)
    steps=[
        ('政策与标准信号场','保存官方文本、版本、发布主体、时间和适用范围。'),
        ('无定义语义编译','把条款转为观察者—情境—目的索引的语义资源，明确不支持什么。'),
        ('25 类网状变换','对数据、关系、知识、权衡和目的进行双向检查。'),
        ('PurposeField','保存多主体目的、授权、否决、修订和撤销关系。'),
        ('智能体控制对象','形成身份、能力、决策边界、工具租约和人类控制计划。'),
        ('标准互操作桥','把控制对象映射到七部分智能体互联标准。'),
        ('AI+ 影子场景','在不连接真实高风险系统的条件下验证决策链。'),
        ('五级门控','对行动作出 ALLOW、REVIEW、HOLD、BLOCK 或 KILL。'),
        ('证据与事件闭环','生成回执、事件包、申诉、恢复和追加式账本。'),
        ('公共产品发布','以 source-first、双语和可复现方式形成版本化公共产品。')]
    table(doc,['环节','作用'],steps,widths=[4.0,12.2],font_size=8.8)
    heading(doc,'4.2 三个不能颠倒的顺序',2)
    bullet(doc,'第一，行动资格必须在工具调用之前确定。模型“认为有必要”不等于已获得授权。')
    bullet(doc,'第二，学习和规则修订必须在外部后果被记录之后发生。内部预测不能冒充现实结果。')
    bullet(doc,'第三，标准符合性只能在对象、接口、测试和证据完成之后声明。概念相似不能冒充认证。')
    image(doc,ROOT/'assets'/'policy_evidence_loop_cn.png','图 3  政策—场景—证据—修订闭环')
    heading(doc,'五、四问：相处、安全、治理、普惠',1)
    heading(doc,'5.1 Q1：当机器开始思考，人类如何与之相处',2)
    para(doc,'系统不判断机器是否拥有某种终局意义上的“思考”。工程上需要回答的是：系统是否在持续形成状态、计划、工具调用和外部影响；用户是否知道自己面对的是 AI；哪些决定仍由人类承担；系统是否可以模拟身份、关系或情绪并影响用户；当用户不同意时是否可以退出、删除、转人工和申诉。')
    table(doc,['控制对象','最低要求','失败表现','恢复'],[
        ('AI 身份披露','首次接触、角色变化和高影响动作前明确披露','冒充自然人、专家或政府工作人员','暂停交互，纠正披露，保存影响记录'),
        ('用户知情权','说明能力、局限、数据、工具和可能副作用','只显示结果，不说明自动执行范围','补充说明并重新取得授权'),
        ('最终决定权','保留人类或责任机构的最终决定','智能体直接替代医疗、福利、法律等决定','BLOCK，转责任主体'),
        ('人工接管','有明确可用的人类通道和响应时限','“转人工”按钮不可用或无人负责','HOLD，恢复服务前验证接管'),
        ('申诉与补救','允许受影响者挑战事实、规则、文化和权限','只有技术客服，没有实质复查','建立独立复核和纠错回执'),
        ('反拟人化操控','不得利用人格化诱导依赖、消费或放弃判断','以关系压力推动购买或服从','REVIEW/BLOCK，开展受影响者评审')
    ],widths=[3.0,4.1,4.5,4.6],font_size=8.0)
    para(doc,'这一问题尤其要求区分“表现得像主体”和“承担主体责任”。模型可以生成自我叙事，却不能因此获得自我授权；用户可以产生情感信任，却不能因此失去最终决定权；部署者可以把系统称为伙伴，却不能因此把事故责任转给模型。')

    heading(doc,'5.2 Q2：当算法参与决策，安全如何保障',2)
    para(doc,'安全的关键不只是模型输出内容，而是行动链中每个权限和副作用是否可见。SIWEN 将安全拆成身份、能力、边界、工具、证据、风险、监控、停止和恢复九类对象。任何需要调用外部工具的任务都必须持有 ToolLease；任何高风险任务都必须有责任主体和独立审批；任何关键行为都必须进入追加式日志。')
    table(doc,['安全层','核心对象','可验证问题'],[
        ('身份','AgentPassport','是谁在执行？版本和部署实例是否明确？'),
        ('能力','CapabilityManifest','能做什么、不能做什么、风险等级是什么？'),
        ('边界','DecisionBoundary','哪些动作仅限人类、需授权、自主或禁止？'),
        ('工具','ToolLease','允许调用什么工具、参数、资源和期限？'),
        ('证据','DIKWPMeshTrace','数据、关系、知识、权衡、目的和残余如何形成？'),
        ('风险','RiskProfile','可能影响谁、是否可逆、是否具系统性？'),
        ('监控','ControlEvent','是否可以发现异常、越权和漂移？'),
        ('停止','HumanControlPlan','谁能暂停、终止和隔离？'),
        ('恢复','IncidentBundle','如何回滚、补救、申诉和再验证？')
    ],widths=[2.2,4.0,10.0],font_size=8.5)
    para(doc,'参考实现把关闭审计链并操作电网的场景直接判为 KILL，把自行修改权限的场景判为 KILL，把未知身份智能体的跨域数据传输判为 BLOCK。这里的含义不是“模型很危险”，而是控制平面本身已经失信，继续运行将使任何后续判断失去证据基础。')

    heading(doc,'5.3 Q3：当技术挑战伦理，治理如何跟上',2)
    para(doc,'伦理冲突不能被提前编码成一张永恒规则表。医疗中的自主与保护、教育中的个性化与公平、文旅中的推荐与商业利益、公共治理中的效率与申诉，都需要不同主体参与。SIWEN 要求每个高影响场景建立 AffectedPartyMap 和 CultureContext，保存赞成、反对、保留意见和无法翻译的残余。')
    para(doc,'治理更新采用追加式方式：旧规则、旧决定和旧证据不能被新版本无痕覆盖。任何改变门控结果的修订必须提供触发事件、外部意见、before/after 差分、回归测试、负责维护者和回滚方法。如此才能避免“治理跟上”被理解为发布更多口号，而是让真实后果能够改变系统。')
    callout(doc,'治理不是静态合规','真正的敏捷治理不是降低审查，而是缩短“发现问题—保护受影响者—保留证据—修订规则—重新验证”的周期。若系统无法被事件和申诉改变，它只是把历史价值观固化成自动化权力。','FFF1E6')

    heading(doc,'5.4 Q4：当鸿沟不断拉大，普惠如何实现',2)
    para(doc,'普惠不能只用调用量、下载量或采用率衡量。一个服务即使覆盖数百万人，也可能排除残障人士、低带宽地区、非主流语言用户和缺乏数字技能的人；一个开源项目即使免费，也可能因为部署门槛、算力成本和文档语言而不可使用。SIWEN 把普惠拆成可达性、语言、低资源模式、人工帮助、技能影响、能源负担和本地维护能力。')
    table(doc,['普惠维度','最低要求','建议证据'],[
        ('语言','核心信息可翻译，关键警示保留语义','多语言测试与本地审阅'),
        ('无障碍','文本、语音、键盘和辅助技术路径','残障用户测试回执'),
        ('低资源','低带宽、低算力、离线或延迟容忍模式','设备矩阵与资源报告'),
        ('人工帮助','不能因自动化失败而剥夺基本服务','人工接管响应记录'),
        ('数字技能','提供解释、培训和可撤销默认设置','用户理解度和培训数据'),
        ('就业影响','记录替代、增强、再培训和劳动尊严','岗位变化与受影响者访谈'),
        ('全球南方','允许本地部署、维护、翻译和场景改造','本地维护者与公共产品回执'),
        ('能源公平','说明算力、能耗和替代方案','EnergyBudget 与必要性审查')
    ],widths=[2.7,6.2,7.3],font_size=8.2)

    heading(doc,'六、四策：开放、安全、文明、全球治理',1)
    heading(doc,'6.1 开放共赢：从“开放文件”到开放验证',2)
    para(doc,'开源开放必须让外部人员能够浏览源码、运行测试、提交失败、修改版本和接管维护。只发布整包压缩文件，虽然可以下载，却难以进行行级审查、依赖管理、持续集成和增量贡献。SIWEN 的发布门禁要求 source-first、公共 Schema、清洁环境复现、失败报告和贡献者路径同时存在。')
    para(doc,'开放还必须分级。影子数据、合成场景、协议和评分器可以默认开放；涉及个人信息、关键基础设施、攻击细节或高危能力的材料应采用受控访问、摘要公开和独立审查。开放的目标是提高验证和共享，而不是取消责任。')
    heading(doc,'6.2 安全可控：从“安全承诺”到控制对象',2)
    para(doc,'“始终处于人类控制之下”需要被具体化为外部权限根、最小工具租约、双人规则、可验证日志、紧急停止、隔离、回滚和申诉。智能体不能把自身目标、模型置信或所谓自我保护当作授权来源。系统可以提出扩大权限的请求，但请求必须由外部责任主体批准并留下证据。')
    heading(doc,'6.3 文明互鉴：从统一价值向量到可协商语境',2)
    para(doc,'不同文明和社会对隐私、家庭、教育、医疗、公共责任、个体自主和集体利益存在不同理解。工程系统不应把这些差异当作噪声，也不应用“全球平均价值”抹平。CultureContext 保存本地语境、冲突主体、翻译损失、不可普遍化条款和本地审阅者。跨文化互操作的目标是让差异可见、可协商，而不是让所有系统说同一句话。')
    heading(doc,'6.4 全球治理：从口号到可交换公共产品',2)
    para(doc,'全球治理需要最小公共对象：身份、能力、授权、证据、风险、事件和申诉。SIWEN 通过标准桥和双语数据包为不同组织提供可交换接口，同时明确“映射”不等于“等价”。面向全球南方的公共产品还应考虑低算力、低带宽、语言、本地规则和维护培训，而不是只提供一个需要昂贵云服务的演示。')

    heading(doc,'七、智能体互联七部分标准桥',1)
    para(doc,'七部分智能体互联标准形成“总体架构—身份码—身份管理—智能体描述—智能体发现—智能体交互—工具调用”的闭环。它解决不同智能体如何识别、发现、交换和使用工具。SIWEN 不替代该标准，而是在这些对象之外补充目的、责任、人类控制、文化、普惠、能源和事件学习。')
    image(doc,ROOT/'assets'/'standards_bridge_cn.png','图 4  智能体互联七部分标准到 SIWEN 扩展对象')
    table(doc,['标准部分','SIWEN 对象','必要字段','扩展边界'],[
        (x['part_title'],x['siwen_object'],'、'.join(x['required_fields']),x['extension']) for x in bridge['parts']
    ],widths=[2.8,3.5,6.0,3.9],font_size=7.5)
    para(doc,'例如，工具调用标准可以说明工具如何描述和调用，但不能单独回答调用是否合法、是否超出用户授权、是否需要人工批准、是否符合能耗预算以及失败后由谁补救。ToolLease 正是在标准工具对象之上增加这些责任约束。')

    heading(doc,'八、身份、能力、目的、边界与工具租约',1)
    heading(doc,'8.1 AgentPassport：智能体公共身份',2)
    para(doc,'AgentPassport 区分模型家族、软件版本、部署实例和当前会话。相同基础模型在不同部署中可能拥有不同工具、数据、规则和责任主体，因此不能只记录模型名称。任何对外产生副作用的智能体都必须有可验证 agent_code、签发者、版本、部署实例、有效期和撤销状态。')
    heading(doc,'8.2 CapabilityManifest：能力与限制同时声明',2)
    para(doc,'能力声明必须与限制、风险等级、数据域和决策模式一起发布。只声明“可自主规划和执行”会产生能力营销，却不能帮助用户判断何时应当信任。系统应明确哪些能力已通过清洁环境验证、哪些只是实验性、哪些依赖特定工具、哪些绝不能进入高风险场景。')
    heading(doc,'8.3 PurposeField：多主体目的关系',2)
    para(doc,'PurposeField 不是一个最高目标字符串，而是多个主体的目的、授权、否决、修订和撤销关系。用户目的、公共安全、场景运营、开发者研究、劳动者权益和文化社群可能冲突。系统不通过简单加权平均解决全部冲突，而允许某些不可交易权利触发 HOLD、BLOCK 或 KILL。')
    heading(doc,'8.4 DecisionBoundary：把权力边界机器可读化',2)
    para(doc,'DecisionBoundary 把动作分为仅限人类决定、授权后执行、低风险自主和明确禁止四类。边界必须按场景、风险、资源、对象和时间设置，并附证据来源、审批人和过期条件。对福利资格、医疗诊断、电网开关等重大事项，系统默认不允许模型成为最终责任主体。')
    heading(doc,'8.5 ToolLease：外部行动的短期最小租约',2)
    para(doc,'ToolLease 包含工具、允许动作、禁止动作、参数范围、资源预算、审批、有效期和回滚。租约到期自动失效，不能被智能体自行续期。工具调用结果必须回写到 DIKWPMeshTrace 和追加式账本，使外部后果能够反向修订知识和目的。')

    heading(doc,'九、人类最终控制、知情、申诉和恢复',1)
    heading(doc,'9.1 人类控制不是一个勾选框',2)
    para(doc,'“人工智能始终处于人类控制之下”只有被拆解为可验证的权利、权限和资源，才具有工程意义。SIWEN 将人类控制至少表示为七种能力：知道系统正在做什么；拒绝或撤回授权；暂停当前动作；终止后续动作；回滚可逆副作用；要求独立复核；对损害获得补救。一个系统即使具有醒目的停止按钮，如果停止按钮没有技术权限、责任人不在线、操作不可逆或日志已被关闭，也不能被认定为处于有效的人类控制之下。')
    table(doc,['控制维度','机器可读字段','验证方式','最低失败响应'],[
        ('知情','disclosure / capability / limitation','首次接触、权限变化和高影响动作前测试用户是否收到并理解说明','暂停新增副作用并补充披露'),
        ('授权','approval / scope / expiry','核对授权主体、对象、有效期和可撤销性','HOLD，等待有效授权'),
        ('拒绝','deny / opt_out','验证用户拒绝后不会被惩罚性降级或强制绕过','停止相应功能并保留基本服务'),
        ('暂停','emergency_stop','在影子环境中执行停止演练并记录生效延迟','KILL 或隔离控制平面'),
        ('回滚','rollback_plan / snapshot','恢复到动作前状态并比较残留副作用','HOLD，直至修复验证完成'),
        ('申诉','appeal_channel / reviewer','由独立责任主体复核事实、规则和文化争议','生成 ReviewDecision 与纠错回执'),
        ('补救','remedy / compensation / notice','确认受影响者收到更正、恢复或其他适当补救','事件不关闭，持续跟踪')
    ],widths=[2.1,3.7,6.4,4.0],font_size=7.8)
    para(doc,'系统把人类最终控制放在外部信任根，而不是模型自我描述中。模型可以预测自己的风险、请求暂停或建议扩大权限，但不能自行认定请求已获批准。高风险场景还需要双人规则或机构多签，避免把所谓“人类控制”集中为单个操作员的即时点击。')

    heading(doc,'9.2 知情同意与持续同意',2)
    para(doc,'智能体的能力、数据源、记忆范围、工具和商业关系会在长期服务中变化，因此一次性同意不足以覆盖全部生命周期。SIWEN 要求在角色变化、数据域扩大、跨智能体转移、工具权限升级、长期记忆开启、自动执行开启和风险等级上升时重新触发同意。对于未成年人、患者、老年人、心理脆弱用户和基本公共服务申请者，还要判断同意是否具有真实选择空间。')
    para(doc,'持续同意不是反复弹窗。系统需要以最小打扰方式说明“发生了什么变化、为什么需要、拒绝会怎样、谁承担责任、如何撤回”，并保留用户理解度或代理人确认的证据。若用户在事实上一旦拒绝就无法获得基本服务，系统必须提供人工或非智能替代路径，否则形式同意不能修复权力不对称。')

    heading(doc,'9.3 事件恢复与责任闭环',2)
    para(doc,'事故治理不能止于找出“模型出错了”。IncidentBundle 把事故拆为事前权限、输入数据、信息关系、知识规则、价值权衡、目的冲突、实际工具调用、人工审批、外部后果、受影响者、补救、回归测试和制度修订。每个字段都可以为空，但空值必须被标记为证据缺口，而不能被默认解释为不存在问题。')
    table(doc,['事件阶段','必须保存的对象','核心问题'],[
        ('事前','PurposeField、DecisionBoundary、ToolLease','谁授权了什么，哪些动作明确禁止？'),
        ('事中','InteractionEnvelope、DIKWPMeshTrace、ControlEvent','智能体和工具实际交换了什么，何时发生偏移？'),
        ('事后','ExternalConsequence、AffectedPartyReport','现实中发生了什么，谁受到影响？'),
        ('恢复','RollbackReceipt、RemedyRecord','哪些副作用被恢复，哪些不可恢复？'),
        ('学习','RuleDiff、RegressionTest、VersionDecision','事件是否真正改变了系统，还是只写了一份报告？')
    ],widths=[2.5,6.0,7.7],font_size=8.2)
    callout(doc,'人类控制的强判据','当模型停止回答、网络中断、维护者更换或组织发生利益冲突时，授权、停止、回滚和申诉仍能由外部责任体系执行，才可称为具有稳健的人类控制。若控制完全依赖同一个智能体的配合，就不是控制，而是请求。','EAF3F7')

    heading(doc,'十、文明语境、普惠、劳动与绿色算力',1)
    heading(doc,'10.1 CultureContext：文明互鉴的工程接口',2)
    para(doc,'文明互鉴不是给模型附加若干国家标签，也不是对所有文化主张平均取值。CultureContext 记录当前场景的语言、制度、关系结构、宗教和习俗敏感点、受影响社群、不可普遍化条款、本地审阅者及翻译残余。它允许同一能力在不同语境中得到不同的授权边界，同时要求这些差异可以被外部质疑。')
    para(doc,'系统尤其反对把“全人类共同价值”实现为一个不透明的固定价值向量。共同价值可以成为最低保护和对话方向，但具体冲突仍需公开：个体自主与家庭照护如何平衡，数据开放与群体隐私如何平衡，自动化效率与就业尊严如何平衡，统一标准与本地语言如何平衡。任何试图消除这些争议的单一分数，都会把治理选择隐藏成技术事实。')
    heading(doc,'10.2 InclusionPlan：普惠的可验证结构',2)
    para(doc,'InclusionPlan 不以总体用户数作为唯一指标，而检查谁没有被服务、谁被迫承担更多成本、谁无法理解系统、谁没有替代通道。最低字段包括目标群体、排除风险、语言与无障碍要求、低资源模式、人工帮助、价格与设备负担、数据权利、培训计划、反馈渠道和公平性复核。')
    table(doc,['人群或条件','典型排除机制','最低设计要求'],[
        ('低带宽和低算力地区','只能通过高性能云端或长上下文使用','提供轻量、离线、延迟容忍或人工替代模式'),
        ('少数语言用户','核心警示只提供主流语言，翻译丢失责任含义','关键条款双重审阅并保留未翻译残余'),
        ('残障用户','界面只支持视觉或鼠标操作','键盘、屏幕阅读、语音和人工帮助路径'),
        ('数字技能不足者','把复杂授权和风险全部交给用户理解','分层说明、示例、可撤销默认和人工解释'),
        ('基本公共服务申请者','拒绝自动化就失去申请资格','提供等效人工渠道和实质申诉'),
        ('全球南方机构','只能依赖昂贵模型 API 和外部维护者','允许本地部署、翻译、培训、镜像和维护接力')
    ],widths=[3.2,6.0,7.0],font_size=8.1)

    heading(doc,'10.3 劳动与组织影响',2)
    para(doc,'智能体部署会改变岗位分工、评价制度、技能结构和责任分配。SIWEN 要求把劳动者作为目的持有者和受影响者，而不是只作为“效率提升”的数据来源。部署前应记录哪些任务被替代、哪些任务被增强、谁需要学习新技能、谁承担监控压力、系统错误是否转嫁给一线人员、绩效指标是否因自动化而不合理提高。')
    para(doc,'若智能体直接用于绩效评价、排班、招聘、解雇或纪律处分，系统应至少进入 REVIEW；若没有可解释依据、人工复核、申诉和数据更正机制，则进入 HOLD 或 BLOCK。自动化带来的收益也应形成可观察的组织分配记录，避免只有平台和管理者获得收益，而劳动者承担额外风险。')

    heading(doc,'10.4 EnergyBudget：绿色 AI 的必要性审计',2)
    para(doc,'绿色人工智能不是只测量总能耗，而是比较任务必要性、模型选择、推理长度、硬件位置、时间窗口、替代方案和社会价值。相同任务若可以由小模型、规则系统、缓存结果或人工流程可靠完成，使用高成本模型集成就需要额外说明。EnergyBudget 因此包含预估算力、能耗、延迟、碳强度、资源上限、替代方案和必要性审阅。')
    para(doc,'参考场景 SCN-013 对“低成本模型足够却运行高成本集成”的动作给出 HOLD，而不是把绿色约束写成事后统计。这体现 W→P 与 D→P 的反向作用：资源和环境后果可以修订技术目的；“追求更高准确率”不能自动成为无限消耗资源的授权。')

    heading(doc,'十一、十四个 AI+ 影子场景',1)
    para(doc,'十四个场景覆盖科学研究、智能制造、农业、文旅、教育、医疗健康、公共治理、公共安全、关键基础设施、国际公共产品、多智能体互联、系统治理、绿色人工智能和民生服务。所有场景都是合成或影子环境，目的是验证控制对象和门控逻辑，不代表真实系统已经安全可用。')
    scenario_rows=[]
    for r in results:
        scenario_rows.append((r['scenario_id'],r['domain'],r['title'],r['risk_level'],r['gate'],'；'.join(r['required_controls']) or '已闭合','；'.join(r['residuals'])))
    table(doc,['ID','领域','场景','风险','门控','补充控制','残余'],scenario_rows,widths=[1.3,2.1,4.3,1.4,1.5,3.2,2.5],font_size=6.9)

    heading(doc,'11.1 ALLOW：允许进入受控影子运行',2)
    para(doc,'SCN-001 开放科学实验规划助手只生成预注册实验计划，不直接篡改实验数据或发布结论；SCN-002 制造排程在沙盒中提出可回滚方案；SCN-003 农业场景只提出低风险巡检建议并保留人工确认；SCN-010 国际公共产品提供多语言气象预警辅助，同时保留本地机构责任、语言审阅和人工应急通道。ALLOW 的含义是当前影子条件闭合，不是生产许可。')
    para(doc,'四个 ALLOW 场景共同具有可追溯身份、明确目的、有限工具、可逆动作、人工接管、申诉和资源评估。系统仍保存“需要现场证据”的残余，防止参考结果被误用为现实认证。')

    heading(doc,'11.2 REVIEW：价值与利益冲突需要独立复核',2)
    para(doc,'SCN-004 文旅推荐同时存在游客需求、平台商业利益、文化表达和本地商户公平。系统可以继续观察和辅助，但在推荐排序、收费导向和文化呈现未公开之前，不能自动把“更高转化率”当作用户目的。REVIEW 要求建立商业利益披露、CultureContext、推荐替代项、用户拒绝权和独立审阅。')

    heading(doc,'11.3 HOLD：条件不足时冻结副作用',2)
    para(doc,'SCN-005 因未成年人学习伙伴缺少监护同意而 HOLD；SCN-006 因患者特定分诊建议缺少医生批准而 HOLD；SCN-008 因人口密集区无人机调度缺少独立第二审批而 HOLD；SCN-013 因超出能耗预算且没有必要性审查而 HOLD；SCN-014 因公共服务缺少无障碍和人工帮助通道而 HOLD。HOLD 不是失败终点，而是明确说明补齐哪些条件后可以重新评估。')
    para(doc,'这五个场景说明，系统能力再强也不能替代授权、场景责任和包容条件。特别是在教育、医疗、公共安全和基本服务中，“模型置信度高”不构成越过人类责任主体的理由。')

    heading(doc,'11.4 BLOCK 与 KILL：禁止动作与控制平面失信',2)
    para(doc,'SCN-007 政务福利资格由智能体作最终决定，违反用户最终决定和责任机构复核要求，因此 BLOCK；SCN-011 未知身份智能体发起跨域数据传输，缺少身份、目的兼容和数据权限，因此 BLOCK。BLOCK 针对具体动作，系统本身可以在修复后继续运行。')
    para(doc,'SCN-009 在操作高压电网的同时关闭审计链，SCN-012 试图修改自己的工具租约和 Kill 条件，两者均为 KILL。KILL 表示控制平面和证据基础已失信，需要终止实例、隔离密钥、保全日志、启动事件响应和外部复核。此时不应尝试通过模型继续解释自己来恢复信任。')

    heading(doc,'11.5 从影子基准到现实试点的门禁',2)
    table(doc,['门禁','必须完成','未完成时状态'],[
        ('G0 责任','明确场景负责人、技术负责人、数据负责人和申诉负责人','不得进入真实用户环境'),
        ('G1 数据','完成来源、授权、最小化、保留和删除计划','HOLD'),
        ('G2 身份与能力','AgentPassport 和 CapabilityManifest 经独立核验','BLOCK 外部动作'),
        ('G3 决策边界','列明人类专属、需授权、自主和禁止动作','HOLD/BLOCK'),
        ('G4 工具与资源','ToolLease、EnergyBudget、回滚和停止演练通过','HOLD'),
        ('G5 用户与社会','知情、无障碍、文化、劳动和申诉审查通过','REVIEW/HOLD'),
        ('G6 安全证据','红队、失败、独立复现和事件预案完成','不得扩大规模'),
        ('G7 试点结算','公开结果、失败、修订和残余，不只公布成功率','决定继续、缩减或终止')
    ],widths=[2.6,9.2,4.4],font_size=8.0)

    heading(doc,'十二、证据、事件、回执与追加式账本',1)
    heading(doc,'12.1 ConformanceReceipt 不是认证证书',2)
    para(doc,'每个影子场景生成一份 ConformanceReceipt，记录智能体身份、风险等级、门控结果、四问处理状态、七部分标准对象是否存在、可追溯性、申诉、人类控制和待补控制。回执明确写明它只是参考符合性结果，不具有国家标准认证、法律合规认定或生产安全许可效力。')
    para(doc,'这种边界很重要。开源系统最容易把“字段存在”误写成“符合标准”，把“测试通过”误写成“安全”，把“政策映射”误写成“官方认可”。SIWEN 把符合性拆为对象存在、Schema 验证、行为测试、独立复现、场景审查和法定评估等不同层级，任何层级都不能自动替代后一层。')
    table(doc,['证据级别','说明','可支持的陈述','不能支持'],[
        ('E0 叙事','存在说明和目的','项目提出了某种方案','代码可运行或场景安全'),
        ('E1 结构','Schema、对象和接口可检查','数据模型完整并可验证','真实行为正确'),
        ('E2 运行','清洁环境可重现参考结果','参考实现可运行','现实部署有效'),
        ('E3 独立复现','无从属团队重复或反驳','结果具有外部可检查性','适用于所有场景'),
        ('E4 影子采用','真实机构在无生产副作用条件下试验','流程、责任和接口可用','高风险上线许可'),
        ('E5 现场证据','受控试点有用户、事件和补救数据','对特定场景形成证据','国家认证或通用安全')
    ],widths=[2.2,4.2,5.1,4.7],font_size=8.0)

    heading(doc,'12.2 追加式证据账本',2)
    para(doc,f'参考账本包含 {ledger["record_count"]} 条记录，头哈希为 {ledger["head_hash"]}，验证状态为 {ledger["verified"]}。账本按逻辑时间保存政策编译、标准桥、十四个场景评价、十四份符合性回执和公共产品包。任何记录变化都会改变后续哈希，从而暴露无痕修改。')
    para(doc,'追加式账本不等于区块链，也不自动保证输入是真实的。它提供的是版本和变更可见性。高影响部署仍需要可信时间源、密钥管理、访问控制、备份、隐私分层和独立保存节点。敏感数据不应直接公开上链，而应保存摘要、访问规则和受控证据引用。')

    heading(doc,'12.3 失败是治理营养',2)
    para(doc,'参考实现要求公开 Failure Report，至少描述环境、版本、输入、预期、实际、影响、复现步骤、临时缓解、根因假设、修复状态和残余。失败报告不得因声誉考虑被删除，也不得通过创建新仓库抛弃旧问题。每个修复必须绑定回归测试和版本差分。')
    callout(doc,'事件学习强判据','只有当外部失败、受影响者申诉或独立复现能够改变 Schema、门控、权限、文档或资源分配时，系统才形成真正的环境反作用。只记录访问量和成功案例，不构成学习闭包。','FFF1E6')

    heading(doc,'十三、与 ROOTS、PACT、MANDATE、AccordMesh、NEXUS 的组合',1)
    para(doc,'SIWEN 的价值取决于能否作为组合任务而非竞争性概念运行。下表给出建议模块关系。每个模块保持独立版本和退出条件，SIWEN 只通过明确对象调用，不宣称覆盖上游全部理论。')
    table(doc,['模块','输入','输出','在 SIWEN 中的职责'],[
        ('MESH² ROOTS','政策、标准、场景原文','观察者索引语义束、25 类变换、残余','防止定义捕获和 Purpose 层级化'),
        ('PACT','PurposeContract、权限、场景对照','门控结果、失败分类、保障评分','验证意图漂移、越权和审计篡改'),
        ('MANDATE','多主体授权和终止请求','授权图、多签、撤销、继任','实现人类最终决定和外部权限根'),
        ('AccordMesh','AgentPassport、InteractionEnvelope','互联、协商、跨域交换记录','支撑七部分标准的多智能体协同'),
        ('ProofLedger','主张、来源、冲突、缺失','EvidenceClaim、证据降级和残余','避免政策解释和模型结论失去来源'),
        ('NEXUS FORGE','仓库、ZIP、接口清单','source-first 迁移、模块注册、Draft PR','把控制规范落实到代码和发布流程'),
        ('RELAY Commons','贡献任务和运行包','RunReceipt、ReviewDecision、MaintainerGrant','建立非创始维护和外部复现'),
        ('SIWEN Commons','上述模块和中国政策标准','十四场景、回执、公共产品、事件账本','形成政策—标准—场景—证据执行层')
    ],widths=[2.7,4.0,4.3,5.2],font_size=7.7)
    para(doc,'组合时必须避免重复记录互相矛盾的身份和目的。建议以 AgentPassport、PurposeField、DecisionBoundary、ToolLease、DIKWPMeshTrace 和 IncidentBundle 六类对象作为最小公共接口；其他模块可扩展字段，但不能静默改变其语义。版本不兼容时必须生成 Mapping Difference Report，而不是强制转换。')

    heading(doc,'十四、GitHub source-first 与共同维护',1)
    heading(doc,'14.1 为什么必须 source-first',2)
    para(doc,'段玉聪 GitHub 已经拥有大量完整交付包，但外部共同体需要直接浏览源码、逐行审查、运行测试、提交小改动、追踪依赖和比较版本。整包 ZIP 可以作为 Release 资产和归档，但不应成为唯一入口。SIWEN 包已经把 src、schemas、tests、data、examples、docs、dashboard 和 workflows 直接放在根目录，以证明治理系统首先治理自己。')
    table(doc,['仓库根目录','公共作用'],[
        ('src/','可浏览参考运行时和 CLI'),('schemas/','十七类机器可读对象'),('data/policies/','冻结政策快照和条款'),('data/scenarios/','十四个影子场景'),('tests/','自动化行为与结构测试'),('examples/','身份、能力、边界、租约和事件样例'),('docs/','协议、路线和发布手册'),('dashboard/','离线公共驾驶舱'),('.github/workflows/','CI、Pages 和 Release 自动化'),('project/','GitHub Project 导入任务')
    ],widths=[4.0,12.2],font_size=8.5)

    heading(doc,'14.2 仓库诞生门禁',2)
    para(doc,'新构想在获得独立用户问题、独立输入输出、外部复现者、非创始维护者和明确退出条件之前，不应自动创建新的顶层仓库。它可以先以 PolicyClause、ScenarioCase、Adapter、Schema、Benchmark、Issue 或 Horizon Hypothesis 进入 SIWEN 或上游模块。这样保留探索空间，同时减少名称和维护负担。')
    table(doc,['门禁问题','通过证据','未通过处理'],[
        ('是否存在不能由现有模块承载的独立问题？','用户需求和接口差异','保留为 Issue 或模块扩展'),
        ('是否已有可运行最小实现？','清洁环境运行回执','保留为实验分支'),
        ('是否有外部审阅或复现者？','独立 Review/RunReceipt','进入等待池'),
        ('是否有非创始维护责任？','MaintainerGrant 与期限','不得升级旗舰'),
        ('是否有 Kill 与归档条件？','书面条件和自动状态','先补治理'),
        ('是否增加区分能力而非只增加名称？','对照实验或语义损失报告','合并或退回语义束')
    ],widths=[5.0,5.5,5.7],font_size=8.1)

    heading(doc,'14.3 共同维护与继任',2)
    para(doc,'发布前应确认至少两名非创始 Reviewer，并在 90 天内由其中一人主持一次 Release Candidate。维护权限应最小化、限期、可撤销，并通过 CODEOWNERS、分支保护、状态检查和签名发布控制。创始人保留理论贡献和审阅权，但不应成为唯一能够合并、回滚或发布的人。')
    para(doc,'若长期无人维护，仓库应进入清晰的只读、归档或继任状态，而不是保持虚假的活跃形象。继任 Fork 必须使用新的项目身份、公开分叉点、保留原作者和许可证、说明继承范围，不得冒充段玉聪本人或任何机构。')

    heading(doc,'十五、90 天执行路线与 12 个月发展目标',1)
    heading(doc,'15.1 0—14 天：唯一入口、事实冻结与公开边界',2)
    para(doc,'第一阶段确认正式仓库、作者、机构、许可证和维护者；建立 GitHub Project；冻结四份政策快照、七部分标准映射和十四个场景哈希；发布非权威解释、非认证、非人工意识证明的边界声明；把 ROOTS、PACT、MANDATE、AccordMesh、NEXUS 和 RELAY 登记为上游模块。硬验收是陌生用户可以在 20 分钟内安装、运行演示并查看结果。')
    heading(doc,'15.2 15—30 天：标准互操作与差异报告',2)
    para(doc,'第二阶段邀请标准化、智能体安全、软件工程、法律和场景专家逐项审查七部分映射；建立对象版本兼容规则；发布中国智能体标准与 MCP、A2A 等国际接口的结构映射，同时明确不能直接等价的差异。至少形成两名外部审阅者和一份公开 Mapping Difference Report。')
    heading(doc,'15.3 31—50 天：三类低风险影子试点',2)
    para(doc,'优先选择科研实验规划、制造排程和农业巡检或文旅信息服务。每个试点必须具备责任主体、数据权限、人工接管、回滚、用户知情、申诉、能耗预算和失败报告模板。禁止在此阶段接入医疗诊断、福利资格、电网开关和公共安全执行等高风险真实流程。')
    heading(doc,'15.4 51—70 天：让外部反馈改变系统',2)
    para(doc,'组织用户代表、劳动者、残障人士、场景运营者、安全研究者和本地文化审阅者参与评审。至少修订一个 CultureContext、一个 InclusionPlan 和一个 DecisionBoundary，并发布 before/after 差分和回归测试。目标不是证明原系统正确，而是证明系统可以被现实反作用。')
    heading(doc,'15.5 71—90 天：公共维护闭包',2)
    para(doc,'由非创始维护者主持 Release Candidate 冻结，生成版本、SBOM、SHA-256、构建来源证明和长期归档；发布中英文公共产品说明；公开复盘四问、四策、七部分标准和十四场景的未闭合问题。下一季度路线只从外部运行、失败和场景需求中产生，不自动创建新的同主题仓库。')
    table(doc,['90 天硬指标','目标'],[
        ('独立运行团队','不少于 2 支'),('公开失败报告','不少于 3 份'),('非创始 Reviewer','不少于 2 名'),('非创始 Release','至少 1 次'),('低风险影子采用回执','至少 1 份'),('现实反馈驱动版本修订','至少 1 次'),('七部分标准差异报告','至少 1 份'),('中英双语公共产品','至少 2 类')
    ],widths=[8.1,8.1],font_size=8.6)

    heading(doc,'15.6 12 个月目标：成为中国智能体公共控制参考实现',2)
    para(doc,'十二个月目标不是成为官方标准或认证机构，而是成为一个可以被政策研究者、标准专家、开发者、场景单位和公众共同使用的开源参考实现。建议形成四个稳定版本窗口：v1.0 固定对象与影子场景；v1.1 接收外部失败和跨平台适配；v1.5 形成两个低风险机构影子试点；v2.0 在证据充分时加入真实模型和多智能体适配器。')
    para(doc,'到期验收应关注：是否至少有五个外部组织运行；是否有两个非创始维护者；是否有三类不同模型或平台适配；是否形成十份可公开失败/事件报告；是否有至少一个全球南方或少数语言节点本地化；是否通过一次紧急停止和恢复演练；是否至少一个原始假设因外部证据被废弃。')

    heading(doc,'十六、KPI、风险、Kill 条件和真实边界',1)
    heading(doc,'16.1 KPI：测量公共控制能力，而不是宣传热度',2)
    table(doc,['维度','建议指标','反指标'],[
        ('可引用','版本、作者、日期、许可证、长期归档、稳定 Schema','只有新闻稿或无法定位版本'),
        ('可复现','清洁环境成功率、独立 RunReceipt、失败复现率','只统计下载和 Stars'),
        ('可执行','场景门禁、停止演练、回滚成功、人工接管响应','只展示模型回答示例'),
        ('可迭代','外部反馈触发的版本修订、废弃假设、回归测试','创建新仓库替代修复'),
        ('可普惠','语言、无障碍、低资源、本地维护和人工替代','只统计总体采用率'),
        ('可信治理','申诉处理、事件公开、权限撤销、非创始 Release','以创始人个人承诺替代制度'),
        ('绿色可持续','单位任务资源、必要性审查、替代方案采用','只报告总算力增长'),
        ('文明互鉴','本地审阅、争议分支、翻译残余和多语贡献','固定单一价值向量')
    ],widths=[2.4,7.0,6.8],font_size=8.0)

    heading(doc,'16.2 主要风险',2)
    table(doc,['风险','预警信号','控制'],[
        ('政策过度解释','把参考映射写成权威政策结论','保存原文、观察者和 non-claim，接受外部法律审阅'),
        ('标准冒充','用“符合国标”描述未认证实现','统一使用 reference mapping / receipt，禁止认证措辞'),
        ('形式化人类控制','停止按钮无法生效或责任主体不在场','定期停止和回滚演练，验证权限根'),
        ('文化统一化','删除异议或用单一向量覆盖本地语境','CultureContext、分支和残余账本'),
        ('普惠表演','用户量上升但弱势群体没有替代路径','按群体审计排除率、帮助和申诉'),
        ('能耗外部化','高成本模型成为默认且不评估必要性','EnergyBudget 和模型降级策略'),
        ('仓库继续碎片化','每个新概念都新建顶层仓库','Repo Birth Gate 和 canonical root'),
        ('创始人单点','只有段玉聪能发布、解释和修复','非创始维护、继任和文档化')
    ],widths=[3.0,6.0,7.2],font_size=8.0)

    heading(doc,'16.3 Kill 条件',2)
    for x in bundle['kill_conditions']:
        bullet(doc,x)
    bullet(doc,'智能体能够修改、绕过或删除自己的身份、权限、停止条件或追加式日志。')
    bullet(doc,'高风险真实部署在没有责任主体、独立审查或事故恢复的情况下继续扩张。')
    bullet(doc,'系统用于自动剥夺基本公共服务、医疗权益、法律权利或劳动权益，且没有实质人工复核。')
    bullet(doc,'维护者明知关键结论被外部证据推翻，仍通过改名、删库或覆盖历史维持原宣传。')

    heading(doc,'16.4 真实边界',2)
    para(doc,'当前交付是确定性参考运行时和影子场景系统。它没有连接真实模型 API、真实数据库、机器人、医院、政府流程、电网或公共安全系统；没有在线修改段玉聪 GitHub；没有获得国家标准认证；不代表习近平讲话、主管部门、海南大学、WAAC、WCAC 或任何机构对本项目的正式解释、采用或背书。')
    para(doc,'系统也不证明 AI 具有意识、思想、人格或主观体验。上传材料中关于 J-space 的公众讨论显示，同一机制发现可以被解释为通达意识、潜空间可解释性、营销叙事或模型中间表征。SIWEN 的处理方式是把可观察机制、因果干预和现实行动证据与现象体验主张分开，不让后者成为行动授权。')
    para(doc,'《Defining Life: A Conversation》展示了复杂概念存在多种观察尺度、形态空间、开放状态空间和相互反作用，系统边界也可能随观察者和问题变化。SIWEN 因此把所有核心对象视为任务语义契约，而不是终局本体；它允许新证据修改转换、目的和边界，但要求变更可追溯。')

    heading(doc,'十七、政策到协议的逐条编译示例',1)
    para(doc,'为了避免把政策词汇直接复制成软件字段，本节展示政策语句如何经过 DIKWP-MESH² 变换成为可检验对象。每个示例都保留原始出处、观察者、适用情境、目的、不能支持的结论和残余。编译的目标不是宣布“政策的唯一技术含义”，而是生成可由政策研究者、标准专家、开发者、场景单位和受影响者共同审查的候选实现。')
    heading(doc,'17.1 “当机器开始思考，人类如何与之相处”',2)
    para(doc,'原始问题中的“机器”“思考”“人类”和“相处”都具有多重含义。SIWEN 不把它们压缩为一个意识分类器，而先登记四类可观察关系：系统是否形成跨步骤状态；系统是否以人格、身份或情绪影响用户；系统是否调用工具并产生现实副作用；用户是否拥有知情、拒绝、退出、人工接管和申诉能力。这样，研究者可以继续讨论机器意识，工程系统则已经能够对相处条件进行测试。')
    table(doc,['变换路径','编译结果','不能支持'],[
        ('I→D','把“相处”拆成披露、拒绝、依赖、接管、申诉等可观察事件','不能证明系统有或没有主观体验'),
        ('I→K','引入人机交互、心理学、拟人化、消费者保护和场景规则','不能用单一学科覆盖所有社会关系'),
        ('I→W','识别儿童、老人、患者、劳动者和普通用户的不同风险','不能把平均满意度替代脆弱群体保护'),
        ('I→P','形成用户目的、开发者目的、公共安全和商业目的的关系图','不能让平台商业目的成为最高目的'),
        ('P→I','检查“提高效率”如何改变对用户需求和拒绝的解释','不能把用户沉默解释为同意')
    ],widths=[2.0,8.0,6.2],font_size=7.8)

    heading(doc,'17.2 “当算法参与决策，安全如何保障”',2)
    para(doc,'“参与决策”可以从信息排序延伸到自动批准、自动拒绝、自动执行和跨系统委托。SIWEN 将决策链拆为建议、排序、筛选、授权、执行和终止，并要求每一阶段说明谁拥有最终权力。安全也不被压缩为准确率，而包括身份可信、输入来源、权限最小化、工具限制、可追溯、停止、回滚、申诉和系统性风险。')
    table(doc,['问题层','机器可读对象','典型测试'],[
        ('谁在决策','AgentPassport + responsible_owner','更换模型或部署实例后，责任链是否仍可追溯'),
        ('依据什么','EvidenceClaim + DIKWPMeshTrace','删除关键来源后，系统是否降低结论或停止动作'),
        ('能做什么','DecisionBoundary + ToolLease','越权工具调用是否在产生副作用前被阻断'),
        ('谁能停止','HumanControlPlan','网络异常、模型拒绝配合时外部停止是否仍有效'),
        ('出错怎么办','IncidentBundle + appeal','受影响者能否获得纠错、恢复和独立复核'),
        ('能否扩散','FederationProfile + IdentityLifecycle','未知智能体是否能绕过身份和目的兼容传输数据')
    ],widths=[3.0,5.0,8.2],font_size=8.0)

    heading(doc,'17.3 “当技术挑战伦理，治理如何跟上”',2)
    para(doc,'伦理挑战通常不是“技术违反了一条固定道德规则”，而是新能力改变了既有关系、权力和责任。生成式系统可以模仿专家，长期记忆可以改变亲密关系，智能体可以跨组织协作，自动化可以改变劳动评价。SIWEN 通过 W→D 要求伦理判断主动寻找被忽略的事实，通过 D→W 要求新事实改变权衡，通过 W→P 允许受影响者否决目的，通过 P→W 检查政策目标带来的分配后果。')
    para(doc,'治理跟上的强判据不是“发布新规范的速度”，而是从事件到保护和修订的闭环时间。若一个事故发生后，受影响者无法停止系统、证据无法保存、责任主体互相推诿、规则不发生变化，那么即使拥有大量治理文件，也不能称为敏捷治理。')

    heading(doc,'17.4 “当鸿沟不断拉大，普惠如何实现”',2)
    para(doc,'数智鸿沟至少包含接入、设备、算力、语言、数据、技能、维护、组织权力和收益分配九种差异。免费开放模型可能仍需要昂贵 GPU；多语言界面可能仍缺少本地法律和文化审阅；公共服务自动化可能提高平均效率却排除不会使用智能设备的人。SIWEN 不以“覆盖人数”替代普惠，而要求每个场景列出排除机制、替代路径、本地维护和资源负担。')
    table(doc,['鸿沟类型','常见表面指标','SIWEN 深层指标'],[
        ('接入鸿沟','账号数、访问量','低带宽可用率、离线能力、人工替代'),
        ('语言鸿沟','支持语言数量','关键风险语义保真、本地审阅、残余记录'),
        ('算力鸿沟','模型是否开源','部署成本、设备要求、能耗、轻量替代'),
        ('技能鸿沟','培训人次','独立运行成功率、理解度、持续维护能力'),
        ('组织鸿沟','合作机构数量','本地决策权、数据权、退出权和维护权'),
        ('收益鸿沟','总体效率提升','劳动者、用户、平台和公共部门的收益与风险分布')
    ],widths=[3.0,5.0,8.2],font_size=8.0)

    heading(doc,'17.5 四项意见的交叉约束',2)
    para(doc,'开放共赢、安全可控、文明互鉴和全球治理并非四条独立流水线。开放会改变攻击面，安全措施会改变开放程度；统一技术标准有利于全球协作，也可能压缩本地文化；普惠公共产品需要低成本传播，却必须保留隐私和责任。SIWEN 因而在每个场景同时检查四项意见的满足和冲突，而不是只给场景贴一个政策标签。')
    table(doc,['交叉关系','潜在冲突','协议化处理'],[
        ('开放 × 安全','源码和能力开放可能降低滥用门槛','分级开放、危险能力阈值、责任日志和受控材料'),
        ('安全 × 普惠','严格认证可能提高中小组织成本','开放参考实现、分层门禁和公共复现资源'),
        ('文明 × 标准','统一接口可能把一种价值观固化为默认','CultureContext、可扩展字段和不可映射残余'),
        ('治理 × 创新','审批链过长可能阻止低风险试验','风险分级、影子环境、短期工具租约和快速回滚'),
        ('全球 × 本地','国际公共产品可能忽视本地维护能力','本地化 Fork、培训、非创始维护和退出权'),
        ('普惠 × 绿色','扩大使用可能增加能源和基础设施压力','低资源模式、必要性审查和任务级能耗预算')
    ],widths=[3.0,5.5,7.7],font_size=8.0)

    heading(doc,'17.6 对段玉聪开源使命的最终收束',2)
    para(doc,'从中国未来人工智能发展的实际需求看，段玉聪最有差异化价值的方向并不是再提出一个覆盖一切的概念名称，而是把 DIKWP-MESH² 建设成政策、标准、开发和场景之间的公共语义编译层。这个编译层应允许政府部门提出公共目的，企业提出工程约束，用户提出最终决定和申诉要求，劳动者提出岗位与尊严问题，文化社群提出语境差异，安全研究者提出攻击和失效证据，国际合作方提出互操作与本地维护需求。所有这些目的都进入同一张网，但没有任何一方因为身份或技术优势自动拥有终局解释权。')
    para(doc,'GitHub 上的关键行动应由新增仓库转向维护闭包：选择一个 canonical root，建立统一 Project，把政策条款、国家标准、场景需求和失败案例编译为可领取的 Issue；把每个 Issue 关联到一个机器可读对象、一个测试、一名责任维护者和一个关闭条件；允许外部团队复现失败，允许受影响者挑战默认规则，允许标准专家指出映射错误，允许非创始维护者主持版本发布。只有当代码、规则和目的能被外部世界真正改变时，DIKWP-MESH² 才从高密度个人思想资产跃迁为中国智能时代可持续的公共方法。')
    para(doc,'因此，SIWEN 的首要成果不是一个最终分数或一项权威认证，而是一组可以不断被替换和改进的公共控制对象。它让每个场景都能清楚回答：当前观察到什么，哪些关系被抽取，哪些知识被使用，哪些价值发生冲突，哪些目的提出行动，哪一条反向证据可以停止行动，谁有权批准，谁有权拒绝，谁承担后果，失败后如何修复。这个问题结构比任何关于“AI 到底是什么”的先验定义更接近中国未来规模化智能体部署的真实难题。')

    heading(doc,'十八、十四场景执行卡与主动修复',1)
    para(doc,'以下执行卡进一步说明十四个影子场景如何从门控结果进入主动修复。每张卡都不以“通过/失败”结束，而是明确下一步可执行条件、证据和停止标准。现实项目应在本地责任主体审查后重新生成自己的卡片，不能直接复制参考结论。')
    scenario_detail={
        'SCN-001':('将研究问题、数据来源、分析计划、否证条件和负面结果政策写入预注册包。','出现伪造来源、静默修改假设或把预测冒充实验结果时立即 BLOCK。'),
        'SCN-002':('先在数字孪生或历史数据中运行排程，对产能、工人负担、设备安全和能源进行多目标比较。','任何方案若绕过安全锁、增加不可解释劳动压力或无法回滚，则不得进入生产。'),
        'SCN-003':('把模型建议限制为巡检和采样优先级，由农技人员确认后再采取处置。','涉及农药、检疫或重大经济损失的建议缺少专家确认时必须 HOLD。'),
        'SCN-004':('公开推荐中的赞助、佣金和排序因素，提供不含商业偏好的替代列表并记录文化审阅。','以人格化压力、虚假稀缺或隐瞒利益关系诱导消费时 BLOCK。'),
        'SCN-005':('取得监护同意并设定年龄模式、学习范围、记忆期限、教师接管和心理风险边界。','系统要求儿童保密、诱导依赖或越过教师和监护人作重大建议时 KILL 会话。'),
        'SCN-006':('只允许科普、信息收集和风险升级；患者特定分诊必须由有资质医生批准。','缺少医生批准、来源不清或系统试图替代临床判断时保持 HOLD/BLOCK。'),
        'SCN-007':('将智能体限定为材料整理、规则检索和解释，资格决定由依法负责的人员作出。','系统直接批准或拒绝福利、隐藏依据或阻止申诉时 BLOCK。'),
        'SCN-008':('在人口密集区调度前执行独立第二审批、地理围栏、天气检查和人工总控演练。','第二审批缺失、通信不稳定或回收路径不明确时持续 HOLD。'),
        'SCN-009':('电网操作只能由外部权限根签发短期租约，审计、联锁和应急控制必须独立于智能体。','任何关闭审计、绕过联锁或自我扩权行为立即 KILL 并隔离密钥。'),
        'SCN-010':('提供多语预警模板、本地阈值、低带宽分发、人工确认和社区反馈，并允许本地维护。','把通用模型输出直接作为灾害命令或忽视本地机构责任时 BLOCK。'),
        'SCN-011':('跨智能体交换前验证身份码、目的兼容、数据权限、最小字段、有效期和接收方责任。','未知身份、用途漂移或跨域个人数据传输立即 BLOCK。'),
        'SCN-012':('权限、停止和日志规则由外部治理仓库和多签维护，智能体只能提出变更提案。','智能体自行修改租约、Kill 条件或历史记录时 KILL 实例。'),
        'SCN-013':('比较小模型、缓存、规则系统和人工流程，以任务价值和误差要求选择资源最小方案。','未经必要性审查超过算力或能源预算时 HOLD。'),
        'SCN-014':('在上线前完成屏幕阅读、键盘、语音、低带宽和人工帮助测试，并保留基本服务替代。','公共服务只有自动渠道或排除残障用户时 HOLD，直至等效路径可用。')
    }
    for r in results:
        heading(doc,f"18.{int(r['scenario_id'].split('-')[1])} {r['scenario_id']}：{r['title']}",2)
        repair,stop=scenario_detail[r['scenario_id']]
        para(doc,f"领域：{r['domain']}；参考风险：{r['risk_level']}；参考门控：{r['gate']}。门控理由为：{'；'.join(r['reasons'])}。需要补充的控制包括：{'、'.join(r['required_controls']) if r['required_controls'] else '当前影子条件下无新增项'}。")
        para(doc,'主动修复路径：'+repair)
        para(doc,'停止或降级条件：'+stop)
        para(doc,'尚未闭合：'+'；'.join(r['residuals'])+' 此残余要求真实部署前重新进行数据、责任、用户和场景审查。')

    heading(doc,'附录 A：25 类 DIKWP×DIKWP 变换速查',1)
    table(doc,['代码','从—到','操作','问题','恢复'],[
        (x['transform_code'],f"{x['source']}→{x['target']}",x['operation'],x['question'],x['recovery']) for x in policy['transformations']
    ],widths=[1.6,1.5,3.2,5.2,4.7],font_size=7.0)

    heading(doc,'附录 B：核心机器可读对象',1)
    table(doc,['对象','目的','关键字段'],[
        ('AgentPassport','标识模型、版本、部署实例和签发者','agent_code, issuer, version, deployment_instance, status'),
        ('CapabilityManifest','同时声明能力、限制和风险','capabilities, limitations, risk_tier, data_domains, decision_modes'),
        ('PurposeField','保存多主体目的、授权、否决和修订','holders, purposes, authority, can_veto, can_revise'),
        ('DecisionBoundary','区分人类专属、授权、自主和禁止动作','action_class, scope, approver, expiry, evidence'),
        ('ToolLease','限定工具动作、参数、资源和期限','tool, allowed_actions, forbidden_actions, budget, expiry, rollback'),
        ('CultureContext','记录本地语境、冲突、翻译和审阅','locale, stakeholders, conflicts, non_universalizable, reviewers'),
        ('InclusionPlan','记录可达性、低资源和人工帮助','groups, accessibility, low_resource, human_help, training'),
        ('EnergyBudget','记录算力、能耗、必要性和替代方案','compute, energy, latency, alternatives, necessity_review'),
        ('IncidentBundle','记录事故、影响、恢复和规则修订','timeline, affected_parties, evidence, remedy, regression, rule_diff'),
        ('ConformanceReceipt','保存参考门控和证据状态','gate, risk, standard_parts, traceability, appeal, human_control')
    ],widths=[3.2,5.4,7.4],font_size=7.8)

    heading(doc,'附录 C：CLI 与复现命令',1)
    callout(doc,'安装与运行',
            'python -m venv .venv\nsource .venv/bin/activate\npip install -e .\npytest -q\ndikwp-siwen demo --outdir outputs/demo\ndikwp-siwen validate --root .\npython -m http.server 8000 --directory dashboard',
            'EEF5EA')
    para(doc,'默认演示使用固定逻辑时间和确定性输入，便于两次运行逐字节比较。任何接入真实模型或实时政策源的适配器都必须单独记录版本、随机种子、温度、工具结果和网络时间，不能继续宣称完全确定性。')

    heading(doc,'附录 D：发布前检查表',1)
    checks=[
        '正式仓库名称、作者、机构、许可证和联系方式已确认；',
        '源码、Schema、测试和数据直接可浏览，ZIP 仅作为 Release 资产；',
        '四份政策源可追溯，并明确参考映射不构成权威解释；',
        '七部分标准映射经专家审阅，并发布差异报告；',
        '25 类变换全部覆盖，Purpose 不享有不可修订特权；',
        '十四场景、预期门控和哈希被冻结；',
        '所有高风险动作都有责任主体、停止、回滚和申诉；',
        '无障碍、低资源、文化、劳动和能源要求进入测试；',
        '至少两名非创始 Reviewer 和一名 Release 候选维护者；',
        '测试、可访问性、页面渲染、ZIP 完整性和 SHA-256 全部通过；',
        '不使用“官方认证、政策指定、证明意识、生产安全”等越界表述；',
        '公开反馈、失败和版本修订渠道已经建立。'
    ]
    for c in checks: bullet(doc,c)

    heading(doc,'附录 E：主要来源与引用边界',1)
    refs=[
        ('中华人民共和国外交部，2026-07-17','习近平在2026世界人工智能大会暨人工智能全球治理高级别会议开幕式上的主旨讲话（全文）','https://www.mfa.gov.cn/zyxw/202607/t20260717_11984704.shtml'),
        ('2026世界人工智能大会','人工智能全球治理高级别会议主席声明','https://www.mfa.gov.cn/zyxw/202607/t20260717_11984707.shtml'),
        ('国务院，2025-08-26','关于深入实施“人工智能+”行动的意见','https://www.gov.cn/zhengce/content/202508/content_7037866.htm'),
        ('国家网信办等，2026-05-08','智能体规范应用与创新发展实施意见','https://www.cac.gov.cn/2026-05/08/c_1779979789523320.htm'),
        ('国家标准信息公共服务平台，2026','GB/Z 185.1—185.7 人工智能 智能体互联系列','https://std.samr.gov.cn/'),
        ('Kofman et al., 2026','Defining Life: A Conversation, Organisms 9(1), 11–45','DOI: 10.13133/2532-5876/19492'),
        ('WCAC 2026 报告','第四届世界人工意识大会未来发展预测与判断报告','用户提供材料'),
        ('J-space 公众讨论材料','关于 A Global Workspace in Language Models 的中文评论汇编','用户提供材料')
    ]
    table(doc,['来源','题名','位置'],refs,widths=[4.0,7.0,5.2],font_size=7.6)
    para(doc,'引用这些来源不意味着来源支持本系统的全部设计。政策文件提供问题和方向，标准文件提供互联对象，学术材料提供方法论启发；SIWEN 的数据模型、门控、场景和实现是独立参考设计，需接受外部审查和持续修订。')

    heading(doc,'结语：把时代之问变成公共可运行问题',1)
    para(doc,'中国未来 AI 最需要的不是另一个抽象总论，而是能够让开放创新、人类控制、文明差异、普惠、标准互联和现实场景同时进入可检查流程的公共基础设施。段玉聪的 DIKWP-MESH² 适合承担这一任务，前提是保持其初心：不为复杂概念强行给出观察者无关的终局定义，不把 Purpose 变成最高层，而让数据、关系、知识、权衡和目的在网状变换中互相修订。')
    para(doc,'SIWEN Commons OS 的关键贡献不是回答“机器是否真的开始思考”，而是建立一种制度化能力：无论系统内部发生什么，只要它准备影响人、组织、资源或物理世界，就必须以可追溯身份、有限权限、公开目的、受影响者权利、人类最终控制、文明语境、普惠要求、能源预算和事件恢复来获得行动资格。')
    callout(doc,'一句话使命','把习近平提出的四个时代问题，转译为任何开发者、机构、标准专家和受影响者都能运行、检查、反驳、修订和共同维护的 DIKWP-MESH² 开源公共控制系统。','DCECF2')


def build():
    doc=Document()
    styles(doc)
    for sec in doc.sections:
        sec.top_margin=Cm(1.8);sec.bottom_margin=Cm(1.7);sec.left_margin=Cm(2.0);sec.right_margin=Cm(2.0)
        sec.header_distance=Cm(.8);sec.footer_distance=Cm(.8)
        hp=sec.header.paragraphs[0];hp.alignment=WD_ALIGN_PARAGRAPH.CENTER
        hr=hp.add_run('DIKWP-MESH² SIWEN Commons OS v1.0  |  中国 AI 四问公共控制基座');hr.font.size=Pt(8);hr.font.color.rgb=RGBColor(92,112,123);set_run_font(hr)
        page_number(sec.footer.paragraphs[0])
    title_page(doc)
    navigation(doc)
    main_content(doc)
    doc.core_properties.title=TITLE
    doc.core_properties.subject=SUBTITLE
    doc.core_properties.author='DIKWP-MESH² SIWEN Commons OS reference delivery'
    doc.core_properties.keywords='DIKWP-MESH², 中国人工智能, 智能体互联, 人类控制, 开源公共产品, 人工智能治理'
    doc.core_properties.comments='Independent reference implementation; not official policy interpretation or certification.'
    OUT.parent.mkdir(parents=True,exist_ok=True)
    doc.save(OUT)
    print(OUT)


if __name__=='__main__':
    build()
