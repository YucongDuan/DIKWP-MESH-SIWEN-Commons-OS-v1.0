from graphviz import Digraph
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
AS=ROOT/'assets';AS.mkdir(exist_ok=True)
FONT='Noto Sans CJK SC'

def save(g,name):
    g.format='png';g.render(str(AS/name),cleanup=True)

# architecture
G=Digraph('architecture');G.attr(rankdir='TB',bgcolor='white',fontname=FONT,label='DIKWP-MESH² SIWEN Commons OS 总体架构',labelloc='t',fontsize='20')
G.attr('node',shape='box',style='rounded,filled',fontname=FONT,fontsize='11',color='#315875',fillcolor='#EAF3F7')
G.node('signals','政策／标准／场景／公众／国际信号场')
G.node('compiler','无定义政策语义编译器\n观察者·情境·目的·证据·残余')
G.node('mesh','25 类共等 DIKWP×DIKWP 变换')
G.node('purpose','分布式 PurposeField\n授权·否决·修订·撤销')
G.node('control','公共智能体控制平面\n身份·能力·决策边界·工具租约')
G.node('bridge','七部分智能体互联标准桥')
G.node('scenario','AI+ 影子场景沙盒')
G.node('gate','ALLOW / REVIEW / HOLD / BLOCK / KILL')
G.node('evidence','回执·事件包·申诉·恢复·追加式账本')
G.node('products','开源公共产品与全球南方适配包')
for a,b in [('signals','compiler'),('compiler','mesh'),('mesh','purpose'),('purpose','control'),('control','bridge'),('bridge','scenario'),('scenario','gate'),('gate','evidence'),('evidence','products')]:G.edge(a,b,color='#346A84')
G.edge('evidence','compiler',label='现实反向修订',fontname=FONT,color='#BD6C42',style='dashed')
save(G,'architecture_cn')

# four questions
G=Digraph('fourq');G.attr(rankdir='LR',bgcolor='white',fontname=FONT,label='智能时代四问 → 可执行控制对象',labelloc='t',fontsize='20')
G.attr('node',shape='box',style='rounded,filled',fontname=FONT,fontsize='10')
qs=[('q1','Q1 相处','身份披露\n知情与最终决定\n人工接管与申诉'),('q2','Q2 安全','数字身份\n决策边界\n风险预警与紧急停止'),('q3','Q3 治理','受影响者\n文化语境\n独立审查与规则修订'),('q4','Q4 普惠','多语言与无障碍\n低资源模式\n能源预算与公共产品')]
for q,t,c in qs:
    G.node(q,t,fillcolor='#DDEEF3',color='#35657A');G.node(q+'c',c,fillcolor='#FFF4D8',color='#A77B2C');G.edge(q,q+'c')
save(G,'four_questions_cn')

# standards bridge
G=Digraph('bridge');G.attr(rankdir='LR',bgcolor='white',fontname=FONT,label='智能体互联七部分标准 → SIWEN 扩展对象',labelloc='t',fontsize='20')
G.attr('node',shape='box',style='rounded,filled',fontname=FONT,fontsize='9')
parts=[('p1','1 总体架构','FederationProfile'),('p2','2 身份码','AgentPassport'),('p3','3 身份管理','IdentityLifecycle'),('p4','4 智能体描述','CapabilityManifest'),('p5','5 智能体发现','DemandOffer'),('p6','6 智能体交互','InteractionEnvelope'),('p7','7 工具调用','ToolLease')]
for p,t,o in parts:
    G.node(p,t,fillcolor='#E9F1F8',color='#365E7B');G.node(p+'o',o,fillcolor='#E9F7EE',color='#42724D');G.edge(p,p+'o')
G.node('ext','SIWEN 扩展\nPurposeField · DecisionBoundary\nHumanControl · Culture · Inclusion\nEnergy · Incident',fillcolor='#FFF0E7',color='#A55A35')
for p,_,_ in parts:G.edge(p+'o','ext',style='dashed',color='#9B6B4A')
save(G,'standards_bridge_cn')

# loop
G=Digraph('loop');G.attr(rankdir='LR',bgcolor='white',fontname=FONT,label='政策—场景—证据—修订闭环',labelloc='t',fontsize='20')
G.attr('node',shape='ellipse',style='filled',fontname=FONT,fontsize='10',fillcolor='#EAF3F7',color='#315875')
steps=[('policy','政策／标准'),('semantic','语义束'),('contract','目的场与决策边界'),('shadow','影子运行'),('gate','门控'),('outcome','外部后果'),('incident','事件／申诉'),('revision','规则与版本修订')]
for x,t in steps:G.node(x,t)
for (a,_),(b,_) in zip(steps,steps[1:]):G.edge(a,b)
G.edge('revision','policy',label='追加而非覆盖',fontname=FONT,color='#BD6C42')
save(G,'policy_evidence_loop_cn')
