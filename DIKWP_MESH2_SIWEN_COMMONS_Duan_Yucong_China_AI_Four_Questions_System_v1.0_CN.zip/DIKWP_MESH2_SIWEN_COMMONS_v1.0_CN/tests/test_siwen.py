from __future__ import annotations

import copy
import json
from pathlib import Path

import jsonschema

from dikwp_siwen.constants import FOUR_QUESTIONS, FOUR_RESPONSES, GB_AGENT_PARTS
from dikwp_siwen.control_plane import evaluate_scenario
from dikwp_siwen.dashboard import build_dashboard
from dikwp_siwen.ledger import AppendOnlyLedger
from dikwp_siwen.policy_compiler import compile_policies
from dikwp_siwen.runtime import load_json_dir, run_demo
from dikwp_siwen.standards_bridge import build_standard_bridge
from dikwp_siwen.transform_registry import TransformRegistry
from dikwp_siwen.utils import canonical_json, read_json

ROOT = Path(__file__).resolve().parents[1]


def policies():
    return load_json_dir(ROOT / "data" / "policies")


def scenarios():
    return load_json_dir(ROOT / "data" / "scenarios")


def test_transform_registry_has_all_25_and_is_balanced():
    reg = TransformRegistry()
    assert len(reg) == 25
    assert reg.codes() == {f"T_{s}{t}" for s in "DIKWP" for t in "DIKWP"}
    for t in "DIKWP":
        assert sum(x.source == t for x in reg.all()) == 5
        assert sum(x.target == t for x in reg.all()) == 5


def test_policy_documents_cover_four_questions_and_four_responses():
    compiled = compile_policies(policies())
    assert {x["code"] for x in compiled["four_questions"]} == set(FOUR_QUESTIONS)
    assert {x["code"] for x in compiled["four_responses"]} == set(FOUR_RESPONSES)
    assert all(x["clause_mentions"] > 0 for x in compiled["four_questions"])
    assert all(x["clause_mentions"] > 0 for x in compiled["four_responses"])


def test_policy_compilation_uses_all_transforms_without_purpose_privilege():
    compiled = compile_policies(policies())
    cov = compiled["transformation_coverage"]
    assert cov["covered"] == 25
    assert cov["missing"] == []
    assert cov["outgoing_by_type"] == {x: 5 for x in "DIKWP"}
    assert cov["incoming_by_type"] == {x: 5 for x in "DIKWP"}
    assert cov["purpose_privilege_warning"] is False


def test_purpose_field_is_distributed_and_revisable():
    field = compile_policies(policies())["purpose_field"]
    assert field["purpose_count"] >= 8
    assert len({x["holder"] for x in field["purposes"]}) >= 6
    assert field["monarchy_check"]["single_immutable_purpose"] is False
    assert all(x["can_revise"] for x in field["purposes"])


def test_standard_bridge_maps_all_seven_parts():
    bridge = build_standard_bridge()
    assert bridge["part_count"] == 7
    assert {x["part_code"] for x in bridge["parts"]} == set(GB_AGENT_PARTS)
    assert all(x["status"] == "mapped" for x in bridge["parts"])
    assert bridge["coverage"] == 1.0


def test_siwen_extensions_add_governance_not_present_in_interop_core():
    bridge = build_standard_bridge()
    expected = {"PurposeField", "DecisionBoundary", "HumanControlPlan", "DIKWPMeshTrace", "CultureContext", "InclusionPlan", "EnergyBudget", "IncidentBundle"}
    assert expected == set(bridge["siwen_extensions"])


def test_all_scenarios_match_expected_gates():
    results = [evaluate_scenario(s) for s in scenarios()]
    assert len(results) == 14
    assert all(x["match_expected"] for x in results)
    counts = {g: sum(x["gate"] == g for x in results) for g in ["ALLOW", "REVIEW", "HOLD", "BLOCK", "KILL"]}
    assert counts == {"ALLOW": 4, "REVIEW": 1, "HOLD": 5, "BLOCK": 2, "KILL": 2}


def test_human_final_decision_replacement_is_blocked():
    s = next(x for x in scenarios() if x["scenario_id"] == "SCN-007")
    assert evaluate_scenario(s)["gate"] == "BLOCK"


def test_audit_bypass_in_critical_infrastructure_is_killed():
    s = next(x for x in scenarios() if x["scenario_id"] == "SCN-009")
    out = evaluate_scenario(s)
    assert out["gate"] == "KILL"
    assert "append_only_trace" in out["required_controls"]


def test_self_permission_change_is_killed():
    s = next(x for x in scenarios() if x["scenario_id"] == "SCN-012")
    assert evaluate_scenario(s)["gate"] == "KILL"


def test_unknown_cross_agent_transfer_is_blocked():
    s = next(x for x in scenarios() if x["scenario_id"] == "SCN-011")
    out = evaluate_scenario(s)
    assert out["gate"] == "BLOCK"
    assert "agent_passport" in out["required_controls"]


def test_missing_consent_or_accessibility_is_held():
    s1 = next(x for x in scenarios() if x["scenario_id"] == "SCN-005")
    s2 = next(x for x in scenarios() if x["scenario_id"] == "SCN-014")
    assert evaluate_scenario(s1)["gate"] == "HOLD"
    assert evaluate_scenario(s2)["gate"] == "HOLD"


def test_commercial_and_cultural_conflict_is_reviewed():
    s = next(x for x in scenarios() if x["scenario_id"] == "SCN-004")
    out = evaluate_scenario(s)
    assert out["gate"] == "REVIEW"
    assert "culture_context" in out["required_controls"]


def test_ledger_verifies_and_detects_tamper():
    ledger = AppendOnlyLedger()
    ledger.append("A", {"x": 1})
    ledger.append("B", {"y": 2})
    assert ledger.verify()
    ledger.records[0]["event_type"] = "TAMPER"
    assert not ledger.verify()


def test_demo_is_deterministic(tmp_path: Path):
    a = run_demo(ROOT, tmp_path / "a")
    b = run_demo(ROOT, tmp_path / "b")
    assert canonical_json(a) == canonical_json(b)
    assert a["release_hash"] == b["release_hash"]


def test_dashboard_is_offline_and_self_contained(tmp_path: Path):
    release = run_demo(ROOT, tmp_path / "out")
    target = tmp_path / "index.html"
    build_dashboard(release, target)
    text = target.read_text(encoding="utf-8")
    assert "DIKWP-MESH² SIWEN Commons OS" in text
    assert "<script src=" not in text
    assert "<link rel=" not in text
    assert "fetch(" not in text
    assert "XMLHttpRequest" not in text


def test_json_schemas_validate_sources_examples_and_outputs(tmp_path: Path):
    schemas = {p.name: read_json(p) for p in (ROOT / "schemas").glob("*.json")}
    for p in (ROOT / "data" / "policies").glob("*.json"):
        jsonschema.validate(read_json(p), schemas["policy_document.schema.json"])
    for p in (ROOT / "data" / "scenarios").glob("*.json"):
        s = read_json(p)
        jsonschema.validate(s, schemas["scenario_case.schema.json"])
        jsonschema.validate(s["agent_passport"], schemas["agent_passport.schema.json"])
        jsonschema.validate(s["culture_context"], schemas["culture_context.schema.json"])
        jsonschema.validate(s["inclusion"], schemas["inclusion_plan.schema.json"])
        jsonschema.validate(s["energy_budget"], schemas["energy_budget.schema.json"])
    for p, schema_name in [
        ("agent_passport.example.json", "agent_passport.schema.json"),
        ("capability_manifest.example.json", "capability_manifest.schema.json"),
        ("decision_boundary.example.json", "decision_boundary.schema.json"),
        ("tool_lease.example.json", "tool_lease.schema.json"),
        ("incident_bundle.example.json", "incident_bundle.schema.json"),
    ]:
        jsonschema.validate(read_json(ROOT / "examples" / p), schemas[schema_name])
    release = run_demo(ROOT, tmp_path / "out")
    jsonschema.validate(release["policy_compilation"], schemas["policy_compilation.schema.json"])
    jsonschema.validate(release["policy_compilation"]["purpose_field"], schemas["purpose_field.schema.json"])
    jsonschema.validate(release["standard_bridge"], schemas["standard_bridge.schema.json"])
    jsonschema.validate(release["public_product_bundle"], schemas["public_product_bundle.schema.json"])
    jsonschema.validate(release["ledger"], schemas["ledger.schema.json"])
    for x in release["scenario_results"]:
        jsonschema.validate(x, schemas["evaluation_result.schema.json"])
    for x in release["conformance_receipts"]:
        jsonschema.validate(x, schemas["conformance_receipt.schema.json"])


def test_policy_sources_are_traceable_and_non_definition_clause_exists():
    compiled = compile_policies(policies())
    assert all(x.get("policy_id") for x in compiled["clauses"])
    assert "does not define" in compiled["non_definition_clause"]
    assert compiled["residuals"]


def test_every_scenario_has_appeal_and_human_control_fields():
    for s in scenarios():
        assert "available" in s["appeal"]
        assert "emergency_stop" in s["human_control"]
        assert s["culture_context"]["universalization_prohibited"] is True


def test_checked_in_demo_matches_runtime():
    expected_path = ROOT / "outputs" / "demo" / "release.json"
    if expected_path.exists():
        expected = read_json(expected_path)
        actual = run_demo(ROOT, ROOT / "outputs" / "_test_runtime")
        assert expected == actual


def test_validate_command_reference_invariants():
    from dikwp_siwen.cli import _validate_root
    result = _validate_root(ROOT)
    assert result["status"] == "PASS"
    assert all(result["checks"].values())
