# Governance

## Purpose

The project maintains an open, no-definition DIKWP-MESH² implementation for turning policy and scenario signals into auditable agent-control artifacts. The project may not claim official policy authority or certification authority.

## Decision classes

- Schema changes: two maintainer approvals and compatibility report.
- Gate-policy changes: two maintainer approvals, one independent reviewer, before/after scenario diff.
- New high-risk scenarios: domain expert review and explicit synthetic/shadow labeling.
- Policy text updates: source provenance, timestamp, and change log required.

## Non-founder maintenance

A formal release should be performable by a maintainer other than the original proposer. No individual may silently rewrite the append-only ledger, change historical decisions, or increase their own permissions.

## Appeals

Any affected party may file an appeal that challenges observer frame, purpose representation, evidence quality, cultural context, inclusion impact or gate decision. Appeals are additive records, not deletions.
