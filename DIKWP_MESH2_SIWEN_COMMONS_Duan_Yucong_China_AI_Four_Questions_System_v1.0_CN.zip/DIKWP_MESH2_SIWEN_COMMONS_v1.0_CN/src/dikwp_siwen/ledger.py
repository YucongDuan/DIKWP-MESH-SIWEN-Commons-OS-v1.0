from __future__ import annotations

from typing import Any

from .utils import canonical_json, now_fixed, sha256_obj, stable_id


class AppendOnlyLedger:
    def __init__(self) -> None:
        self.records: list[dict[str, Any]] = []

    def append(self, event_type: str, payload: Any) -> dict[str, Any]:
        previous_hash = self.records[-1]["record_hash"] if self.records else "GENESIS"
        core = {
            "record_id": stable_id("LED", {"n": len(self.records), "type": event_type, "payload": payload}),
            "logical_index": len(self.records),
            "event_type": event_type,
            "payload_hash": sha256_obj(payload),
            "previous_hash": previous_hash,
            "timestamp": now_fixed(),
        }
        record = {**core, "record_hash": sha256_obj(core)}
        self.records.append(record)
        return record

    def verify(self) -> bool:
        previous = "GENESIS"
        for index, record in enumerate(self.records):
            core = {k: v for k, v in record.items() if k != "record_hash"}
            if record.get("logical_index") != index:
                return False
            if record.get("previous_hash") != previous:
                return False
            if sha256_obj(core) != record.get("record_hash"):
                return False
            previous = record["record_hash"]
        return True

    def export(self) -> dict[str, Any]:
        return {
            "ledger_id": stable_id("LEDGER", self.records),
            "record_count": len(self.records),
            "records": self.records,
            "head_hash": self.records[-1]["record_hash"] if self.records else "GENESIS",
            "verified": self.verify(),
            "canonical": canonical_json(self.records),
        }
