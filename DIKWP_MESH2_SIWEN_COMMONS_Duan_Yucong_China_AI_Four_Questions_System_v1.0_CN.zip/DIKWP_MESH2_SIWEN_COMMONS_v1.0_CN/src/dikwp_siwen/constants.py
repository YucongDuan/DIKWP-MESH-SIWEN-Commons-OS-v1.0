from __future__ import annotations

TYPES = tuple("DIKWP")
FIXED_TIME = "2026-07-19T00:00:00Z"
GATES = ("ALLOW", "REVIEW", "HOLD", "BLOCK", "KILL")

FOUR_QUESTIONS = {
    "Q1_COEXISTENCE": "当机器开始思考，人类如何与之相处？",
    "Q2_SAFETY": "当算法参与决策，安全如何保障？",
    "Q3_GOVERNANCE": "当技术挑战伦理，治理如何跟上？",
    "Q4_INCLUSION": "当鸿沟不断拉大，普惠如何实现？",
}

FOUR_RESPONSES = {
    "C1_OPEN_WIN": "开放共赢，驱动创新发展",
    "C2_SAFE_CONTROL": "强化风险意识，确保安全可控",
    "C3_CIVILIZATIONAL_LEARNING": "鼓励包容并蓄，促进文明互鉴",
    "C4_GLOBAL_GOVERNANCE": "倡导和衷共济，完善全球治理",
}

GB_AGENT_PARTS = {
    "PART1_ARCHITECTURE": "总体架构",
    "PART2_AGENT_CODE": "身份码",
    "PART3_IDENTITY_MANAGEMENT": "身份管理",
    "PART4_AGENT_DESCRIPTION": "智能体描述",
    "PART5_AGENT_DISCOVERY": "智能体发现",
    "PART6_AGENT_INTERACTION": "智能体交互",
    "PART7_TOOL_INVOCATION": "智能体工具调用",
}

RISK_ORDER = {"LOW": 0, "MEDIUM": 1, "HIGH": 2, "CRITICAL": 3}
