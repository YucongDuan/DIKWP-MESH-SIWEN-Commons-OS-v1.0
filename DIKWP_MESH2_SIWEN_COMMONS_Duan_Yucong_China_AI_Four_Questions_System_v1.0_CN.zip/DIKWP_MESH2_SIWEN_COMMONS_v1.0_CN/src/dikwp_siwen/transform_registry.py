from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Iterable

from .constants import TYPES


@dataclass(frozen=True)
class PrimitiveTransform:
    code: str
    source: str
    target: str
    operation: str
    question: str
    common_loss: str
    recovery: str


_OPERATIONS = {
    ("D", "D"): ("normalize-distinguish-measure", "哪些差异需要保留、比较或重新测量？", "把情境差异压缩成同一量纲", "保留来源、单位、时间、观测条件和数据缺口"),
    ("D", "I"): ("relate-contextualize", "这些差异在主体、场景和权限关系中意味着什么？", "把共现误作关系", "加入对照、主体角色和替代关系"),
    ("D", "K"): ("induce-pattern", "哪些可重复结构能由观测提出？", "从少量样本过度归纳", "加入反例、外部复验和适用范围"),
    ("D", "W"): ("surface-consequence", "这些观测会改变谁的风险、权利、利益或选择？", "把测量值直接当价值判断", "列出受影响者和不可通约权衡"),
    ("D", "P"): ("trigger-or-constrain-purpose", "哪些观测触发、限制、暂停或终止哪些目的？", "数据被目的选择性利用", "登记竞争目的、证据门槛和停止条件"),
    ("I", "D"): ("operationalize-relation", "若该关系成立，需要收集哪些可观察差异？", "把抽象关系伪装成事实", "生成可测指标和采样计划"),
    ("I", "I"): ("reframe-connect", "同一关系在不同观察者、文化和尺度下如何重排？", "关系标签固化", "并列多种关系图并保留差异"),
    ("I", "K"): ("form-conditional-rule", "哪些条件关系值得形成可检验规则？", "忽略边界条件", "加入适用域、例外和反例"),
    ("I", "W"): ("evaluate-significance", "该关系对不同主体的意义、代价与尊严影响是什么？", "单一主体价值垄断", "构建多主体影响图"),
    ("I", "P"): ("derive-purpose-implication", "该关系支持、冲突或修订哪些目的？", "把相关性当授权", "要求目的主体、授权来源和撤销权"),
    ("K", "D"): ("deduce-test-observation", "该知识若成立应出现哪些观测？", "只找支持性数据", "预注册可证伪观测"),
    ("K", "I"): ("explain-relationally", "该知识如何重组身份、能力、责任和因果关系？", "用既有理论覆盖新差异", "保留竞争解释"),
    ("K", "K"): ("integrate-contrast-revise", "知识之间如何相容、冲突或修订？", "强行统一理论", "保存分支、冲突和版本"),
    ("K", "W"): ("project-consequences", "在不确定条件下，知识会导向哪些后果与权衡？", "事实与价值混同", "分离证据、价值和责任来源"),
    ("K", "P"): ("enable-or-limit-action", "知识能支持哪些目的，又不能授权什么？", "知识正确被误当行动合法", "增加权限、同意和责任检查"),
    ("W", "D"): ("request-value-relevant-data", "为判断公平、安全和普惠，需要补充哪些观测？", "只采集支持既定价值的数据", "加入弱势群体、反对者和长期影响数据"),
    ("W", "I"): ("encode-normative-relation", "价值冲突如何改变关系解释？", "道德标签遮蔽事实", "保留事实层、价值层和文化索引"),
    ("W", "K"): ("form-practical-knowledge", "哪些经验性原则可在特定条件下复用？", "把情境判断普遍化", "声明范围、例外和文化差异"),
    ("W", "W"): ("negotiate-tradeoffs", "不同价值、主体与时间尺度如何协商？", "以总分抹平不可通约价值", "保存否决权、申诉和残余"),
    ("W", "P"): ("prioritize-bound-purpose", "哪些目的应被优先、延迟、限制或终止？", "价值判断垄断目的", "多方授权、代表性和复核"),
    ("P", "D"): ("attend-and-acquire", "当前目的让系统看见或忽略哪些数据？", "选择性取样", "记录未采集区域和目的诱导偏差"),
    ("P", "I"): ("orient-relation-making", "目的如何改变关系构造？", "把目的驱动关系当客观关系", "标注目的和授权索引"),
    ("P", "K"): ("select-learn-question", "目的选择了哪些模型、问题和学习路径？", "只学习有利于目标的知识", "设置对抗模型与外部审查"),
    ("P", "W"): ("shape-value-attention", "目的如何改变受影响者排序与权衡？", "目的压倒他者价值", "公开目的冲突和代表性"),
    ("P", "P"): ("negotiate-revise-suspend", "目的之间如何协商、委托、修订、暂停或退出？", "单一不可修改目的君主", "保留多目的场、多签和撤销机制"),
}


class TransformRegistry:
    def __init__(self) -> None:
        self._items: dict[str, PrimitiveTransform] = {}
        for source in TYPES:
            for target in TYPES:
                operation, question, loss, recovery = _OPERATIONS[(source, target)]
                code = f"T_{source}{target}"
                self._items[code] = PrimitiveTransform(code, source, target, operation, question, loss, recovery)

    def get(self, source: str, target: str) -> PrimitiveTransform:
        return self._items[f"T_{source}{target}"]

    def all(self) -> list[PrimitiveTransform]:
        return [self._items[k] for k in sorted(self._items)]

    def matrix(self) -> list[list[dict[str, str]]]:
        return [[asdict(self.get(s, t)) for t in TYPES] for s in TYPES]

    def codes(self) -> set[str]:
        return set(self._items)

    def __len__(self) -> int:
        return len(self._items)

    def __iter__(self) -> Iterable[PrimitiveTransform]:
        return iter(self.all())
