from __future__ import annotations

from collections import Counter
from typing import Any

from .constants import FOUR_QUESTIONS, FOUR_RESPONSES, TYPES
from .transform_registry import TransformRegistry
from .utils import now_fixed, sha256_obj, stable_id


QUESTION_CONTROL_MAP = {
    "Q1_COEXISTENCE": [
        "ai_identity_disclosure", "user_informed_right", "user_final_decision",
        "human_handoff", "appeal_and_remedy", "anti_deception",
    ],
    "Q2_SAFETY": [
        "agent_identity", "decision_boundary", "tool_lease", "risk_tier",
        "traceability", "warning", "emergency_stop", "recovery",
    ],
    "Q3_GOVERNANCE": [
        "affected_party_map", "culture_context", "conflict_ledger",
        "independent_review", "dynamic_rule_revision", "incident_reporting",
    ],
    "Q4_INCLUSION": [
        "accessibility", "multilingual_support", "low_resource_mode",
        "human_help_channel", "energy_budget", "public_good_bundle",
        "skills_and_labor_impact",
    ],
}

RESPONSE_PRODUCT_MAP = {
    "C1_OPEN_WIN": ["source_first_repo", "open_schema", "clean_reproduction", "failure_report", "contributor_path"],
    "C2_SAFE_CONTROL": ["decision_boundary", "tool_lease", "human_control_plan", "incident_bundle", "kill_conditions"],
    "C3_CIVILIZATIONAL_LEARNING": ["culture_context", "observer_frame", "non_universalization_clause", "translation_loss_ledger"],
    "C4_GLOBAL_GOVERNANCE": ["standard_bridge", "bilingual_bundle", "global_south_profile", "federation_receipt"],
}


def _purpose_field(policies: list[dict[str, Any]]) -> dict[str, Any]:
    purposes: list[dict[str, Any]] = []
    seen: set[str] = set()
    for p in policies:
        for item in p.get("purposes", []):
            key = f"{item['holder']}::{item['purpose']}"
            if key in seen:
                continue
            seen.add(key)
            purposes.append({
                "purpose_id": stable_id("PUR", item),
                "holder": item["holder"],
                "purpose": item["purpose"],
                "authority": item.get("authority", "declared"),
                "can_veto": bool(item.get("can_veto", False)),
                "can_revise": bool(item.get("can_revise", True)),
                "revocation": item.get("revocation", "human or institutional review"),
            })
    purposes.sort(key=lambda x: (x["holder"], x["purpose"]))
    immutable = [x for x in purposes if not x["can_revise"] and not x["revocation"]]
    return {
        "field_id": stable_id("PF", purposes),
        "purposes": purposes,
        "purpose_count": len(purposes),
        "monarchy_check": {
            "single_immutable_purpose": len(purposes) == 1 and bool(immutable),
            "policy": "Purpose is a distributed, revisable field. No policy sentence or model objective alone grants action authority.",
        },
    }


def compile_policies(policies: list[dict[str, Any]]) -> dict[str, Any]:
    registry = TransformRegistry()
    clauses: list[dict[str, Any]] = []
    q_counter: Counter[str] = Counter()
    r_counter: Counter[str] = Counter()
    for policy in policies:
        for clause in policy.get("clauses", []):
            item = dict(clause)
            item["policy_id"] = policy["policy_id"]
            item["policy_title"] = policy["title"]
            item["clause_id"] = item.get("clause_id") or stable_id("CL", item)
            item.setdefault("observer", policy.get("issuer", "public institution"))
            item.setdefault("context", policy.get("context", "China AI development and governance"))
            item.setdefault("does_not_claim", ["scientific proof of consciousness", "automatic authorization"])
            clauses.append(item)
            for q in item.get("questions", []):
                q_counter[q] += 1
            for r in item.get("responses", []):
                r_counter[r] += 1
    clauses.sort(key=lambda x: (x["policy_id"], x["clause_id"]))

    transforms: list[dict[str, Any]] = []
    # Every primitive is exercised once against the whole policy field. This is a semantic coverage
    # record, not a claim that every clause has a single correct DIKWP type.
    for primitive in registry:
        source_count = sum(1 for c in clauses if c.get("primary_resource") == primitive.source)
        target_controls = sum(1 for c in clauses if primitive.target in c.get("target_resources", []))
        transforms.append({
            "event_id": stable_id("TR", {"code": primitive.code, "clauses": [c["clause_id"] for c in clauses]}),
            "transform_code": primitive.code,
            "source": primitive.source,
            "target": primitive.target,
            "operation": primitive.operation,
            "question": primitive.question,
            "common_loss": primitive.common_loss,
            "recovery": primitive.recovery,
            "source_clause_count": source_count,
            "target_resource_mentions": target_controls,
            "status": "covered",
        })

    missing_questions = [q for q in FOUR_QUESTIONS if q_counter[q] == 0]
    missing_responses = [r for r in FOUR_RESPONSES if r_counter[r] == 0]
    residuals = [
        "Policy language does not by itself determine a machine-checkable control threshold.",
        "Cultural diversity cannot be reduced to a single fixed value vector without local participation.",
        "Human final control requires real operational authority, not a user-interface label.",
        "Interoperability standards identify exchange objects but do not alone settle responsibility for consequences.",
        "Inclusion and energy impacts require field measurements after deployment.",
    ]

    result = {
        "compilation_id": stable_id("PC", clauses),
        "generated_at": now_fixed(),
        "policy_count": len(policies),
        "clause_count": len(clauses),
        "four_questions": [
            {"code": code, "question": text, "clause_mentions": q_counter[code], "required_controls": QUESTION_CONTROL_MAP[code]}
            for code, text in FOUR_QUESTIONS.items()
        ],
        "four_responses": [
            {"code": code, "response": text, "clause_mentions": r_counter[code], "required_public_products": RESPONSE_PRODUCT_MAP[code]}
            for code, text in FOUR_RESPONSES.items()
        ],
        "clauses": clauses,
        "purpose_field": _purpose_field(policies),
        "transformations": transforms,
        "transformation_coverage": {
            "covered": len(transforms),
            "total": 25,
            "missing": [],
            "outgoing_by_type": {t: 5 for t in TYPES},
            "incoming_by_type": {t: 5 for t in TYPES},
            "purpose_privilege_warning": False,
        },
        "gaps": {"missing_questions": missing_questions, "missing_responses": missing_responses},
        "residuals": residuals,
        "non_definition_clause": "The compilation records observer-, context- and purpose-indexed semantic relations; it does not define intelligence, agency, safety, culture, inclusion or consciousness once and for all.",
    }
    result["compilation_hash"] = sha256_obj(result)
    return result
