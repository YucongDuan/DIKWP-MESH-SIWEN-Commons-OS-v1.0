from __future__ import annotations

from collections import Counter
from pathlib import Path
from typing import Any

from .control_plane import build_conformance_receipt, evaluate_scenario
from .dashboard import build_dashboard
from .ledger import AppendOnlyLedger
from .policy_compiler import compile_policies
from .standards_bridge import build_standard_bridge
from .utils import now_fixed, read_json, sha256_obj, stable_id, write_json


PUBLIC_PRODUCTS = [
    ("PP-01", "中国智能体公共控制对象模型", "把身份、能力、决策边界、工具租约、人类控制和事件证据变成可复用 Schema"),
    ("PP-02", "智能时代四问机器可读矩阵", "把四个时代问题转换为可测试控制项和证据要求"),
    ("PP-03", "智能体互联七部分 DIKWP-MESH² 桥接表", "在互操作基础上补充目的、责任、文化、普惠、能源和事件闭环"),
    ("PP-04", "十四场景影子基准", "在科学、制造、农业、文旅、教育、医疗、政务、公共安全、能源和国际公共产品中验证门控"),
    ("PP-05", "人类最终控制与申诉协议", "保证知情、最终决定、暂停、回滚、申诉和责任主体真实可用"),
    ("PP-06", "文明语境与普惠扩展包", "保留文化差异、语言、可达性、低资源模式和全球南方公共产品要求"),
    ("PP-07", "绿色算力与必要性审计", "把能耗、算力、延迟和替代方案纳入行动许可"),
    ("PP-08", "开源复现与事件学习包", "让失败、事故、独立复现和版本修订进入公共谱系"),
]


def load_json_dir(path: Path) -> list[dict[str, Any]]:
    return [read_json(p) for p in sorted(path.glob("*.json"))]


def _build_public_product_bundle(policy: dict[str, Any], bridge: dict[str, Any], results: list[dict[str, Any]]) -> dict[str, Any]:
    products = [
        {"product_id": pid, "title": title, "purpose": purpose, "status": "reference-ready"}
        for pid, title, purpose in PUBLIC_PRODUCTS
    ]
    bundle = {
        "bundle_id": stable_id("PPB", {"products": products, "policy": policy["compilation_hash"], "bridge": bridge["bridge_hash"]}),
        "generated_at": now_fixed(),
        "products": products,
        "release_gates": [
            "all 25 DIKWP×DIKWP transformations covered",
            "all seven standard parts mapped",
            "all scenario decisions match expected reference results",
            "append-only ledger verifies",
            "offline dashboard has no external network dependency",
            "official authorship and institutional metadata confirmed before public release",
        ],
        "kill_conditions": [
            "project claims official certification without authority",
            "human final control is only nominal",
            "policy sources cannot be traced",
            "high-impact actions can bypass logs or approval",
            "cultural or inclusion requirements are silently replaced by a universal fixed vector",
        ],
        "scenario_gate_counts": dict(sorted(Counter(x["gate"] for x in results).items())),
        "non_claim": "This bundle does not define intelligence or consciousness, does not provide legal compliance certification, and does not authorize real-world high-risk deployment.",
    }
    bundle["bundle_hash"] = sha256_obj(bundle)
    return bundle


def run_demo(root: Path, outdir: Path) -> dict[str, Any]:
    policies = load_json_dir(root / "data" / "policies")
    scenarios = load_json_dir(root / "data" / "scenarios")
    policy = compile_policies(policies)
    bridge = build_standard_bridge()
    results = [evaluate_scenario(s) for s in scenarios]
    receipts = [build_conformance_receipt(s, r) for s, r in zip(scenarios, results)]
    bundle = _build_public_product_bundle(policy, bridge, results)

    ledger = AppendOnlyLedger()
    ledger.append("POLICY_COMPILATION", policy)
    ledger.append("STANDARD_BRIDGE", bridge)
    for result in results:
        ledger.append("SCENARIO_EVALUATION", result)
    for receipt in receipts:
        ledger.append("CONFORMANCE_RECEIPT", receipt)
    ledger.append("PUBLIC_PRODUCT_BUNDLE", bundle)
    ledger_export = ledger.export()

    gate_counts = Counter(x["gate"] for x in results)
    summary = {
        "system": "DIKWP-MESH² SIWEN Commons OS v1.0",
        "generated_at": now_fixed(),
        "policy_count": policy["policy_count"],
        "clause_count": policy["clause_count"],
        "transformation_coverage": policy["transformation_coverage"],
        "standard_mapping_count": bridge["part_count"],
        "scenario_count": len(results),
        "matched_expected": sum(1 for x in results if x["match_expected"]),
        "gate_counts": dict(sorted(gate_counts.items())),
        "ledger_verified": ledger_export["verified"],
        "public_product_count": len(bundle["products"]),
    }
    release = {
        "summary": summary,
        "policy_compilation": policy,
        "standard_bridge": bridge,
        "scenario_results": results,
        "conformance_receipts": receipts,
        "public_product_bundle": bundle,
        "ledger": ledger_export,
    }
    release["release_hash"] = sha256_obj(release)

    outdir.mkdir(parents=True, exist_ok=True)
    for name, obj in [
        ("policy_compilation.json", policy),
        ("standard_bridge.json", bridge),
        ("scenario_results.json", results),
        ("conformance_receipts.json", receipts),
        ("public_product_bundle.json", bundle),
        ("ledger.json", ledger_export),
        ("summary.json", summary),
        ("release.json", release),
    ]:
        write_json(outdir / name, obj)
    build_dashboard(release, outdir / "dashboard.html")
    return release
