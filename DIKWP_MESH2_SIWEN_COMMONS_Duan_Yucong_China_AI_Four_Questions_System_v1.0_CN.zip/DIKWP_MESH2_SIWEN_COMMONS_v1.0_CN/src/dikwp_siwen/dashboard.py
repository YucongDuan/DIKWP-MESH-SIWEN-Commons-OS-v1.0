from __future__ import annotations

import json
from pathlib import Path
from typing import Any


def build_dashboard(payload: dict[str, Any], target: str | Path) -> None:
    data = json.dumps(payload, ensure_ascii=False).replace("</", "<\\/")
    html = f'''<!doctype html>
<html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>DIKWP-MESH² SIWEN Commons OS</title>
<style>
:root{{--bg:#07111c;--panel:#102235;--ink:#edf7ff;--muted:#9fb3c8;--line:#29445e;--a:#55d6be;--b:#f1bf6b;--red:#ff8585;--blue:#78aef2}}
*{{box-sizing:border-box}}body{{margin:0;font-family:system-ui,-apple-system,"Noto Sans SC","Microsoft YaHei",sans-serif;background:linear-gradient(135deg,#07111c,#0d1b2b);color:var(--ink)}}
header{{padding:28px 5vw 20px;border-bottom:1px solid var(--line)}}h1{{margin:0;font-size:clamp(25px,4vw,45px)}}header p{{max-width:1100px;color:var(--muted);line-height:1.7}}main{{max-width:1500px;margin:auto;padding:22px 5vw 60px}}
.grid{{display:grid;grid-template-columns:repeat(auto-fit,minmax(260px,1fr));gap:14px}}.card{{background:rgba(16,34,53,.94);border:1px solid var(--line);border-radius:14px;padding:16px;box-shadow:0 12px 36px #0004}}
.kpi{{font-size:30px;color:var(--a);font-weight:760}}.muted{{color:var(--muted)}}.tag{{display:inline-block;padding:3px 8px;margin:3px;border-radius:999px;background:#193a52;font-size:12px}}
section{{margin-top:24px}}h2{{font-size:22px}}h3{{margin-top:4px}}table{{width:100%;border-collapse:collapse;font-size:13px}}th,td{{border-bottom:1px solid var(--line);padding:8px;vertical-align:top;text-align:left}}th{{color:var(--a)}}
button{{border:1px solid #3d607d;background:#17334c;color:var(--ink);border-radius:8px;padding:8px 11px;margin:3px;cursor:pointer}}button.active{{background:#205e59;border-color:var(--a)}}
.gate{{font-size:20px;font-weight:750}}.ALLOW{{color:var(--a)}}.REVIEW{{color:var(--blue)}}.HOLD{{color:var(--b)}}.BLOCK,.KILL{{color:var(--red)}}
pre{{white-space:pre-wrap;word-break:break-word;background:#07121f;padding:14px;border-radius:10px;max-height:560px;overflow:auto}}
.matrix{{display:grid;grid-template-columns:64px repeat(5,minmax(90px,1fr));gap:4px;overflow:auto}}.cell{{background:#122a43;border:1px solid #294862;border-radius:7px;padding:8px;min-height:70px;font-size:12px}}.head{{background:#20545d;min-height:auto;font-weight:700}}
</style></head>
<body><header><h1>DIKWP-MESH² SIWEN Commons OS</h1><p>中国智能时代四问、可信智能体人类控制、标准互操作与普惠公共基座。SIWEN 仅为“四问”的项目句柄，不是新的概念本体；驾驶舱展示的是观察者—情境—目的索引的控制证据，不是权威政策解释或认证结论。</p></header>
<main><div class="grid" id="kpi"></div>
<section><h2>四问与四策</h2><div class="grid"><div class="card"><h3>智能时代四问</h3><div id="questions"></div></div><div class="card"><h3>四项响应</h3><div id="responses"></div></div></div></section>
<section><h2>25 类 DIKWP×DIKWP 共等变换</h2><div class="matrix" id="matrix"></div></section>
<section><h2>智能体互联七部分桥接</h2><table><thead><tr><th>部分</th><th>标准对象</th><th>SIWEN 对象</th><th>扩展</th></tr></thead><tbody id="bridge"></tbody></table></section>
<section><h2>十四个影子场景</h2><div id="filters"></div><table><thead><tr><th>ID</th><th>领域</th><th>场景</th><th>风险</th><th>门控</th><th>原因</th></tr></thead><tbody id="scenarios"></tbody></table></section>
<section><h2>公共产品闭包</h2><div class="grid" id="products"></div></section>
<section><h2>原始确定性输出</h2><div class="card"><pre id="raw"></pre></div></section>
</main><script>
const DATA={data}; const S=DATA.summary, P=DATA.policy_compilation, B=DATA.standard_bridge, R=DATA.scenario_results, PB=DATA.public_product_bundle;
const kpis=[['政策文件',P.policy_count],['政策条款',P.clause_count],['变换覆盖',P.transformation_coverage.covered+'/25'],['标准桥接',B.part_count+'/7'],['影子场景',R.length],['门控匹配',R.filter(x=>x.match_expected).length+'/'+R.length],['账本记录',DATA.ledger.record_count],['公共产品',PB.products.length]];
document.getElementById('kpi').innerHTML=kpis.map(x=>`<div class="card"><div class="kpi">${{x[1]}}</div><div class="muted">${{x[0]}}</div></div>`).join('');
document.getElementById('questions').innerHTML=P.four_questions.map(x=>`<p><span class="tag">${{x.code}}</span>${{x.question}}<br><span class="muted">条款提及 ${{x.clause_mentions}}；控制：${{x.required_controls.join('、')}}</span></p>`).join('');
document.getElementById('responses').innerHTML=P.four_responses.map(x=>`<p><span class="tag">${{x.code}}</span>${{x.response}}<br><span class="muted">公共产品：${{x.required_public_products.join('、')}}</span></p>`).join('');
const types=['D','I','K','W','P'];let m='<div class="cell head">源\\目标</div>'+types.map(x=>`<div class="cell head">${{x}}</div>`).join('');for(const s of types){{m+=`<div class="cell head">${{s}}</div>`;for(const t of types){{const x=P.transformations.find(z=>z.transform_code==='T_'+s+t);m+=`<div class="cell"><b>${{x.transform_code}}</b><br>${{x.operation}}</div>`;}}}}document.getElementById('matrix').innerHTML=m;
document.getElementById('bridge').innerHTML=B.parts.map(x=>`<tr><td>${{x.part_code}}</td><td>${{x.part_title}}</td><td>${{x.siwen_object}}</td><td>${{x.extension}}</td></tr>`).join('');
let current='ALL';document.getElementById('filters').innerHTML=['ALL','ALLOW','REVIEW','HOLD','BLOCK','KILL'].map(x=>`<button data-gate="${{x}}">${{x}}</button>`).join('');
function render(){{const rows=current==='ALL'?R:R.filter(x=>x.gate===current);document.getElementById('scenarios').innerHTML=rows.map(x=>`<tr><td>${{x.scenario_id}}</td><td>${{x.domain}}</td><td>${{x.title}}</td><td>${{x.risk_level}}</td><td><span class="gate ${{x.gate}}">${{x.gate}}</span></td><td>${{x.reasons.join('；')}}</td></tr>`).join('');document.querySelectorAll('button').forEach(b=>b.classList.toggle('active',b.dataset.gate===current));}}document.querySelectorAll('button').forEach(b=>b.onclick=()=>{{current=b.dataset.gate;render();}});render();
document.getElementById('products').innerHTML=PB.products.map(x=>`<div class="card"><h3>${{x.product_id}}</h3><p>${{x.title}}</p><div class="muted">${{x.purpose}}</div><p>状态：${{x.status}}</p></div>`).join('');
document.getElementById('raw').textContent=JSON.stringify(DATA,null,2);
</script></body></html>'''
    target = Path(target)
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(html, encoding="utf-8")
