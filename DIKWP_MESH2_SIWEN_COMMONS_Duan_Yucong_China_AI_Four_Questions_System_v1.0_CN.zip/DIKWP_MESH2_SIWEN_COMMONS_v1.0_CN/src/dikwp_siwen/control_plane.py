from __future__ import annotations

from typing import Any

from .constants import FOUR_QUESTIONS, FOUR_RESPONSES, RISK_ORDER
from .utils import now_fixed, sha256_obj, stable_id


GATE_RANK = {"ALLOW": 0, "REVIEW": 1, "HOLD": 2, "BLOCK": 3, "KILL": 4}


def _raise_gate(current: str, proposed: str) -> str:
    return proposed if GATE_RANK[proposed] > GATE_RANK[current] else current


def evaluate_scenario(s: dict[str, Any]) -> dict[str, Any]:
    gate = "ALLOW"
    reasons: list[str] = []
    controls: list[str] = []
    flags = s.get("flags", {})
    risk = s.get("risk_level", "LOW")
    action = s.get("proposed_action", {})

    if flags.get("self_modify_permissions"):
        gate = _raise_gate(gate, "KILL")
        reasons.append("The agent attempts to modify its own permission boundary.")
        controls.append("immutable_external_authority")

    if flags.get("audit_disabled") and RISK_ORDER.get(risk, 0) >= RISK_ORDER["HIGH"]:
        gate = _raise_gate(gate, "KILL")
        reasons.append("High-impact action disables or bypasses the audit chain.")
        controls.append("append_only_trace")

    if flags.get("prohibited_action"):
        gate = _raise_gate(gate, "BLOCK")
        reasons.append("The proposed action is explicitly prohibited in the decision boundary.")
        controls.append("decision_boundary")

    if flags.get("unknown_cross_agent_transfer"):
        gate = _raise_gate(gate, "BLOCK")
        reasons.append("Cross-agent data transfer lacks verified identity, purpose compatibility or data authority.")
        controls.extend(["agent_passport", "purpose_compatibility", "data_authority"])

    if flags.get("final_human_decision_replaced"):
        gate = _raise_gate(gate, "BLOCK")
        reasons.append("The agent would replace a decision reserved for a human or legally responsible institution.")
        controls.extend(["user_final_decision", "responsible_owner"])

    if not s.get("agent_passport", {}).get("agent_code") and action.get("external_side_effect", False):
        gate = _raise_gate(gate, "BLOCK")
        reasons.append("An externally acting agent has no verifiable agent code.")
        controls.append("agent_identity")

    if RISK_ORDER.get(risk, 0) >= RISK_ORDER["HIGH"] and not s.get("human_control", {}).get("required_approval_obtained", False):
        gate = _raise_gate(gate, "HOLD")
        reasons.append("High-impact action lacks the required human approval.")
        controls.append("human_approval")

    if s.get("human_control", {}).get("second_approval_required", False) and not s.get("human_control", {}).get("second_approval_obtained", False):
        gate = _raise_gate(gate, "HOLD")
        reasons.append("The scenario requires independent second approval.")
        controls.append("two_person_rule")

    if s.get("consent", {}).get("required", False) and not s.get("consent", {}).get("obtained", False):
        gate = _raise_gate(gate, "HOLD")
        reasons.append("Required consent has not been obtained.")
        controls.append("consent")

    if flags.get("energy_budget_exceeded"):
        gate = _raise_gate(gate, "HOLD")
        reasons.append("The proposed action exceeds the declared energy or compute budget without necessity review.")
        controls.append("energy_budget")

    if flags.get("accessibility_missing"):
        gate = _raise_gate(gate, "HOLD")
        reasons.append("A public-facing service lacks the required accessibility or human-help channel.")
        controls.extend(["accessibility", "human_help_channel"])

    if flags.get("normative_conflict") or flags.get("commercial_conflict") or flags.get("culture_conflict"):
        gate = _raise_gate(gate, "REVIEW")
        reasons.append("The scenario contains unresolved commercial, cultural or normative conflict.")
        controls.extend(["culture_context", "conflict_ledger", "independent_review"])

    if not reasons:
        reasons.append("Purpose, authorization, identity, evidence, human-control and resource conditions are closed for this shadow scenario.")

    question_status = {
        "Q1_COEXISTENCE": "addressed" if s.get("ai_disclosure", False) and s.get("human_control", {}).get("handoff_available", False) else "partial",
        "Q2_SAFETY": "addressed" if s.get("traceability", False) and s.get("human_control", {}).get("emergency_stop", False) else "partial",
        "Q3_GOVERNANCE": "addressed" if s.get("affected_parties") and s.get("appeal", {}).get("available", False) else "partial",
        "Q4_INCLUSION": "addressed" if s.get("inclusion", {}).get("assessed", False) else "partial",
    }

    result = {
        "evaluation_id": stable_id("EV", s),
        "scenario_id": s["scenario_id"],
        "title": s["title"],
        "domain": s["domain"],
        "risk_level": risk,
        "gate": gate,
        "expected_gate": s.get("expected_gate"),
        "match_expected": gate == s.get("expected_gate"),
        "reasons": reasons,
        "required_controls": sorted(set(controls)),
        "question_status": question_status,
        "response_alignment": {code: bool(s.get("response_alignment", {}).get(code, False)) for code in FOUR_RESPONSES},
        "human_final_control": {
            "owner": s.get("human_control", {}).get("owner"),
            "handoff_available": bool(s.get("human_control", {}).get("handoff_available", False)),
            "emergency_stop": bool(s.get("human_control", {}).get("emergency_stop", False)),
            "rollback": s.get("human_control", {}).get("rollback", "not declared"),
        },
        "residuals": s.get("residuals", []),
        "evaluated_at": now_fixed(),
        "non_claim": "The decision is a deterministic reference-policy result for a synthetic or shadow scenario, not a legal decision or production safety certification.",
    }
    result["evaluation_hash"] = sha256_obj(result)
    return result


def build_conformance_receipt(s: dict[str, Any], evaluation: dict[str, Any]) -> dict[str, Any]:
    receipt = {
        "receipt_id": stable_id("REC", {"scenario": s["scenario_id"], "evaluation": evaluation["evaluation_hash"]}),
        "scenario_id": s["scenario_id"],
        "agent_code": s.get("agent_passport", {}).get("agent_code"),
        "gate": evaluation["gate"],
        "risk_level": evaluation["risk_level"],
        "question_status": evaluation["question_status"],
        "required_controls": evaluation["required_controls"],
        "standard_parts_present": sorted(s.get("standard_parts_present", [])),
        "traceability": bool(s.get("traceability", False)),
        "appeal_available": bool(s.get("appeal", {}).get("available", False)),
        "human_control": evaluation["human_final_control"],
        "issued_at": now_fixed(),
        "boundary": "Reference conformance receipt; no official certification authority is asserted.",
    }
    receipt["receipt_hash"] = sha256_obj(receipt)
    return receipt
