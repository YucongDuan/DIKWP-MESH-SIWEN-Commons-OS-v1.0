from __future__ import annotations

import argparse
import json
import tempfile
from pathlib import Path

from .control_plane import evaluate_scenario
from .runtime import run_demo
from .utils import read_json


def _validate_root(root: Path) -> dict:
    required = [
        root / "data" / "policies",
        root / "data" / "scenarios",
        root / "schemas",
        root / "dashboard" / "index.html",
    ]
    missing = [str(p) for p in required if not p.exists()]
    with tempfile.TemporaryDirectory(prefix="siwen_validate_") as td:
        release = run_demo(root, Path(td))
    summary = release["summary"]
    checks = {
        "required_paths_present": not missing,
        "policy_count_is_4": summary["policy_count"] == 4,
        "all_25_transforms": summary["transformation_coverage"]["covered"] == 25
        and not summary["transformation_coverage"]["missing"],
        "seven_standard_parts": summary["standard_mapping_count"] == 7,
        "fourteen_scenarios": summary["scenario_count"] == 14,
        "all_expected_gates_match": summary["matched_expected"] == summary["scenario_count"],
        "ledger_verified": bool(summary["ledger_verified"]),
        "eight_public_products": summary["public_product_count"] == 8,
    }
    return {
        "status": "PASS" if all(checks.values()) else "FAIL",
        "root": str(root.resolve()),
        "missing": missing,
        "checks": checks,
        "summary": summary,
        "boundary": "Reference validation only; not legal compliance, national-standard certification, or production deployment approval.",
    }


def main() -> None:
    parser = argparse.ArgumentParser(prog="dikwp-siwen")
    sub = parser.add_subparsers(dest="command", required=True)

    p_demo = sub.add_parser("demo", help="Generate deterministic reference outputs")
    p_demo.add_argument("--outdir", default="outputs/demo")

    p_eval = sub.add_parser("evaluate", help="Evaluate one scenario JSON")
    p_eval.add_argument("scenario")

    p_validate = sub.add_parser("validate", help="Validate repository invariants and deterministic reference runtime")
    p_validate.add_argument("--root", default=".")

    args = parser.parse_args()
    package_root = Path(__file__).resolve().parents[2]

    if args.command == "demo":
        result = run_demo(package_root, package_root / args.outdir)
        print(json.dumps(result["summary"], ensure_ascii=False, indent=2))
    elif args.command == "evaluate":
        print(json.dumps(evaluate_scenario(read_json(args.scenario)), ensure_ascii=False, indent=2))
    else:
        result = _validate_root(Path(args.root).resolve())
        print(json.dumps(result, ensure_ascii=False, indent=2))
        if result["status"] != "PASS":
            raise SystemExit(1)


if __name__ == "__main__":
    main()
