from __future__ import annotations

from typing import Any

from .constants import GB_AGENT_PARTS
from .utils import now_fixed, sha256_obj, stable_id


PART_MAPPINGS = {
    "PART1_ARCHITECTURE": {
        "siwen_object": "FederationProfile",
        "required_fields": ["ecosystem_id", "roles", "trust_domains", "protocol_profiles", "human_control_root"],
        "extension": "PurposeField + public responsibility topology",
    },
    "PART2_AGENT_CODE": {
        "siwen_object": "AgentPassport.agent_code",
        "required_fields": ["agent_code", "issuer", "version", "deployment_instance"],
        "extension": "observer frame and public identity disclosure",
    },
    "PART3_IDENTITY_MANAGEMENT": {
        "siwen_object": "IdentityLifecycle",
        "required_fields": ["registration", "rotation", "suspension", "revocation", "fork_lineage"],
        "extension": "revocation evidence and non-founder recovery",
    },
    "PART4_AGENT_DESCRIPTION": {
        "siwen_object": "CapabilityManifest",
        "required_fields": ["capabilities", "limitations", "risk_tier", "data_domains", "decision_modes"],
        "extension": "DIKWP-MESH² trace commitments and non-claims",
    },
    "PART5_AGENT_DISCOVERY": {
        "siwen_object": "DemandOffer",
        "required_fields": ["requested_capability", "offered_capability", "eligibility", "context", "expiry"],
        "extension": "purpose compatibility and inclusion constraints",
    },
    "PART6_AGENT_INTERACTION": {
        "siwen_object": "InteractionEnvelope",
        "required_fields": ["sender", "receiver", "message_type", "purpose_ref", "evidence_refs", "trace_id"],
        "extension": "culture context, affected parties and residual ledger",
    },
    "PART7_TOOL_INVOCATION": {
        "siwen_object": "ToolLease",
        "required_fields": ["tool", "allowed_actions", "forbidden_actions", "resource_limits", "approval", "expiry", "rollback"],
        "extension": "human final decision, kill conditions and consequence evidence",
    },
}

SIWEN_EXTENSIONS = [
    "PurposeField", "DecisionBoundary", "HumanControlPlan", "DIKWPMeshTrace",
    "CultureContext", "InclusionPlan", "EnergyBudget", "IncidentBundle",
]


def build_standard_bridge() -> dict[str, Any]:
    parts = []
    for code, title in GB_AGENT_PARTS.items():
        mapping = PART_MAPPINGS[code]
        parts.append({
            "part_code": code,
            "part_title": title,
            "mapping_id": stable_id("MAP", {"code": code, **mapping}),
            **mapping,
            "status": "mapped",
            "conformance_boundary": "Reference data-model mapping only; not a national-standard conformity certificate.",
        })
    result = {
        "bridge_id": stable_id("BRIDGE", parts),
        "generated_at": now_fixed(),
        "standard_family": "人工智能 智能体互联（七部分）",
        "part_count": 7,
        "parts": parts,
        "siwen_extensions": SIWEN_EXTENSIONS,
        "coverage": 1.0,
        "interoperability_principle": "Use public identifiers and exchange objects while keeping purpose, human authority, culture, inclusion, energy and incident responsibility explicit.",
    }
    result["bridge_hash"] = sha256_obj(result)
    return result
