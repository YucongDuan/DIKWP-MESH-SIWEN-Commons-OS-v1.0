# Contributing

Contributions are welcomed in five forms:

1. independent clean-environment reproduction;
2. new synthetic or shadow scenarios with explicit responsibility boundaries;
3. mappings to public standards and international protocols;
4. failure reports and counterexamples;
5. accessibility, language and Global South public-good adaptations.

Every pull request must state: observer frame, intended purpose, evidence, what the change does not claim, tests, rollback, and affected parties.
