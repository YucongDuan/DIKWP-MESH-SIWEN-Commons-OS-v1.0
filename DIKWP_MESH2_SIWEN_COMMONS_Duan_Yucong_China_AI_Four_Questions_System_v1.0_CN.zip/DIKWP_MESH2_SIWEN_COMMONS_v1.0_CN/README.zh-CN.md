# DIKWP-MESH² SIWEN Commons OS v1.0

## 中国智能时代四问、可信智能体人类控制、标准互操作与普惠公共基座

`SIWEN` 只是“四问”的工程句柄，不是新的概念本体，也不位于 DIKWP-MESH² 之上。

本系统把政策、标准、场景、主体和风险信号编译为带观察者、情境、目的、证据和残余索引的语义资源，并通过全部 25 类共等 `DIKWP×DIKWP` 变换形成：

- 分布式目的场与决策边界；
- 智能体身份、能力、工具租约和人类最终控制；
- ALLOW / REVIEW / HOLD / BLOCK / KILL 五级门控；
- 与七部分智能体互联标准的机器可读映射；
- 文明语境、普惠可达、绿色算力、事件证据和国际公共产品扩展；
- 14 个确定性影子场景、追加式账本和离线驾驶舱。

## 运行

```bash
python -m venv .venv
source .venv/bin/activate
pip install -e .[dev]
dikwp-siwen demo --outdir outputs/demo
pytest -q
dikwp-siwen validate --root .
```

## 边界

本项目是独立参考实现，不构成政策权威解释、法律意见、认证结论、国家标准符合性证书，也不代表段玉聪、海南大学、WAAC、WCAC 或任何政府机构已批准、采用或背书。
