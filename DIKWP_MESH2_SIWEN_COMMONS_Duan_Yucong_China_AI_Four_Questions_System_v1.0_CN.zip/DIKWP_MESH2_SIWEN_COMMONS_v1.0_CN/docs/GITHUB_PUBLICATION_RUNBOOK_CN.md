# GitHub 正式发布操作手册

1. 新建 canonical source-first 仓库。
2. 复制本包源码，不要只上传 ZIP。
3. 核对作者、机构、许可证、引用和 NOTICE。
4. 启用 Issues、Discussions、Actions、Projects 和分支保护。
5. 配置 CODEOWNERS，至少包含一名非创始维护者候选人。
6. 运行 `pytest -q` 和 `dikwp-siwen demo`。
7. 比较 `outputs/demo/release.json` 与冻结哈希。
8. 发布 Release Candidate，不立即声称标准符合性或官方采用。
9. 邀请独立团队复现并提交 Run Receipt / Failure Report。
10. 根据外部结果发布 v1.0.1 或撤回相关主张。

公开首页只推荐少数 canonical 入口。本系统应作为 ROOTS、PACT、MANDATE、AccordMesh、NEXUS 的组合任务，而不是继续制造同义项目竞争。
