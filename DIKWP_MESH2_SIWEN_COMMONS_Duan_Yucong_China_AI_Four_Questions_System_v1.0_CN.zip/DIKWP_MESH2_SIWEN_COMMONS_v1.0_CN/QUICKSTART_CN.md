# 快速启动

## 1. 安装

```bash
python -m venv .venv
source .venv/bin/activate
pip install -e .[dev]
```

Windows PowerShell：

```powershell
python -m venv .venv
.venv\Scripts\Activate.ps1
pip install -e .[dev]
```

## 2. 生成确定性演示

```bash
dikwp-siwen demo --outdir outputs/demo
```

输出包括：

- `policy_compilation.json`
- `standard_bridge.json`
- `scenario_results.json`
- `conformance_receipts.json`
- `public_product_bundle.json`
- `ledger.json`
- `summary.json`
- `dashboard.html`

## 3. 运行测试

```bash
pytest -q
```

## 4. 单场景评估

```bash
dikwp-siwen evaluate "data/scenarios/SCN-007-公共治理.json"
```

## 5. 验证仓库不变量

```bash
dikwp-siwen validate --root .
```

## 6. 打开驾驶舱

直接打开 `dashboard/index.html`。驾驶舱不请求外部网络资源，也不上传数据。
